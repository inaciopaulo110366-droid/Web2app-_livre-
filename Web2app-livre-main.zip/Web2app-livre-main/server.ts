import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import zlib from 'node:zlib';
import * as cheerio from 'cheerio';
import dotenv from 'dotenv';
import express from 'express';
import type { Request, Response } from 'express';
import JSZip from 'jszip';
import { buildSignedAndroidApk } from './apkBuilder.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === 'production';

// Persistent remote config cache for live Auto-Update endpoints
const DATA_DIR = path.resolve(__dirname, 'data');
const REMOTE_CONFIG_FILE = path.join(DATA_DIR, 'remote-configs.json');

interface RemoteAppConfig {
  id: string;
  name: string;
  websiteUrl: string;
  packageName: string;
  iconUrl: string;
  themeColor: string;
  splashBgColor: string;
  splashAnimation: string;
  versionName: string;
  versionCode: number;
  autoUpdateEnabled: boolean;
  autoSyncIcon: boolean;
  showNavBar: boolean;
  pullToRefresh: boolean;
  fullscreenMode: boolean;
  lockMobileViewport: boolean;
  disableZoom: boolean;
  openExternalApps: boolean;
  permCamera: boolean;
  permMicrophone: boolean;
  permLocation: boolean;
  permFiles: boolean;
  permBiometrics: boolean;
  orientation: string;
  updatedAt: string;
}

const remoteConfigs = new Map<string, RemoteAppConfig>();

function loadRemoteConfigs() {
  try {
    if (fs.existsSync(REMOTE_CONFIG_FILE)) {
      const raw = fs.readFileSync(REMOTE_CONFIG_FILE, 'utf-8');
      const parsed = JSON.parse(raw) as Record<string, RemoteAppConfig>;
      for (const [k, v] of Object.entries(parsed)) {
        remoteConfigs.set(k, v);
      }
    }
  } catch {
    // Start fresh if cache file is unreadable
  }
}

function saveRemoteConfigs() {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    const obj: Record<string, RemoteAppConfig> = {};
    for (const [k, v] of remoteConfigs.entries()) {
      obj[k] = v;
    }
    fs.writeFileSync(REMOTE_CONFIG_FILE, JSON.stringify(obj, null, 2));
  } catch {
    // Non-fatal persistence fallback
  }
}

loadRemoteConfigs();

function isBlockedHostname(hostname: string): boolean {
  const lower = hostname.toLowerCase();
  if (
    lower === 'localhost' ||
    lower === '0.0.0.0' ||
    lower === '::1' ||
    lower === '[::1]' ||
    lower.endsWith('.local') ||
    lower.endsWith('.internal')
  ) {
    return true;
  }
  const ipv4Match = lower.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (ipv4Match) {
    const a = Number(ipv4Match[1]);
    const b = Number(ipv4Match[2]);
    if (
      a === 127 ||
      a === 10 ||
      a === 0 ||
      (a === 169 && b === 254) ||
      (a === 192 && b === 168) ||
      (a === 172 && b >= 16 && b <= 31)
    ) {
      return true;
    }
  }
  return false;
}

function normalizeUrlInput(rawUrl: string): URL | null {
  const trimmed = rawUrl.trim();
  if (!trimmed) return null;
  const withProto = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  try {
    const parsed = new URL(withProto);
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      return null;
    }
    if (isBlockedHostname(parsed.hostname)) {
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

function buildPackageName(hostname: string): string {
  const parts = hostname
    .toLowerCase()
    .replace(/^www\./, '')
    .split('.')
    .filter(Boolean)
    .map((p) => p.replace(/[^a-z0-9]/g, ''))
    .filter(Boolean);
  const slug = parts[0] ? parts[0].replace(/^[0-9]+/, 'app') || 'meuapp' : 'meuapp';
  const safeSlug = /^[a-z]/.test(slug) ? slug : `app${slug}`;
  return `com.web2app.${safeSlug.slice(0, 32)}`;
}

function normalizeHexColor(val: string | undefined): string {
  if (!val) return '#2563EB';
  const trimmed = val.trim();
  if (/^#[0-9a-fA-F]{6}$/.test(trimmed)) return trimmed.toUpperCase();
  const shortMatch = trimmed.match(/^#([0-9a-fA-F])([0-9a-fA-F])([0-9a-fA-F])$/);
  if (shortMatch) {
    return `#${shortMatch[1]}${shortMatch[1]}${shortMatch[2]}${shortMatch[2]}${shortMatch[3]}${shortMatch[3]}`.toUpperCase();
  }
  return '#2563EB';
}

function parseIconSize(sizesAttr: string | undefined): number {
  if (!sizesAttr) return 0;
  const match = sizesAttr.match(/(\d+)\s*x\s*(\d+)/i);
  return match ? Number(match[1]) : 0;
}

function crc32(buf: Buffer): number {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c ^= buf[i];
    for (let k = 0; k < 8; k++) {
      c = (c >>> 1) ^ (c & 1 ? 0xedb88320 : 0);
    }
  }
  return (c ^ 0xffffffff) >>> 0;
}

function pngChunk(type: string, data: Buffer): Buffer {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const typeBuf = Buffer.from(type, 'ascii');
  const crcInput = Buffer.concat([typeBuf, data]);
  const crcBuf = Buffer.alloc(4);
  crcBuf.writeUInt32BE(crc32(crcInput), 0);
  return Buffer.concat([len, typeBuf, data, crcBuf]);
}

function generateSolidPngBuffer(hexColor: string, size = 192): Buffer {
  const cleanHex = normalizeHexColor(hexColor).slice(1);
  const r = parseInt(cleanHex.slice(0, 2), 16);
  const g = parseInt(cleanHex.slice(2, 4), 16);
  const b = parseInt(cleanHex.slice(4, 6), 16);

  const rowStride = 1 + size * 4;
  const raw = Buffer.alloc(rowStride * size);
  const center = size / 2;
  const radius = size * 0.44;

  for (let y = 0; y < size; y++) {
    const rowStart = y * rowStride;
    raw[rowStart] = 0; // Filter type 0
    for (let x = 0; x < size; x++) {
      const idx = rowStart + 1 + x * 4;
      const dx = Math.abs(x - center);
      const dy = Math.abs(y - center);
      const cornerDist = Math.hypot(Math.max(dx - radius * 0.55, 0), Math.max(dy - radius * 0.55, 0));
      const inRoundedRect = cornerDist <= radius * 0.45 && dx <= radius && dy <= radius;
      const inInnerEmblem =
        Math.abs(x - center) <= size * 0.16 && Math.abs(y - center) <= size * 0.16;

      if (!inRoundedRect) {
        raw[idx] = 0;
        raw[idx + 1] = 0;
        raw[idx + 2] = 0;
        raw[idx + 3] = 0;
      } else if (inInnerEmblem) {
        raw[idx] = 255;
        raw[idx + 1] = 255;
        raw[idx + 2] = 255;
        raw[idx + 3] = 255;
      } else {
        raw[idx] = r;
        raw[idx + 1] = g;
        raw[idx + 2] = b;
        raw[idx + 3] = 255;
      }
    }
  }

  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(size, 0);
  ihdr.writeUInt32BE(size, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // RGBA
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;

  const compressed = zlib.deflateSync(raw);
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  return Buffer.concat([
    signature,
    pngChunk('IHDR', ihdr),
    pngChunk('IDAT', compressed),
    pngChunk('IEND', Buffer.alloc(0)),
  ]);
}

async function resolveIconPngBuffer(iconUrl: string, themeColor: string): Promise<Buffer> {
  if (iconUrl && iconUrl.startsWith('data:image/png;base64,')) {
    const b64 = iconUrl.slice('data:image/png;base64,'.length);
    const buf = Buffer.from(b64, 'base64');
    if (buf.length > 8 && buf[0] === 0x89 && buf[1] === 0x50) {
      return buf;
    }
  }
  if (iconUrl && /^https?:\/\//i.test(iconUrl)) {
    try {
      const parsed = new URL(iconUrl);
      if (!isBlockedHostname(parsed.hostname)) {
        const resp = await fetch(parsed.toString(), {
          signal: AbortSignal.timeout(5000),
          headers: { 'User-Agent': 'Mozilla/5.0 Web2AppLivre/1.0' },
        });
        if (resp.ok) {
          const ct = resp.headers.get('content-type') || '';
          if (ct.includes('png')) {
            const arr = Buffer.from(await resp.arrayBuffer());
            if (arr.length > 8 && arr[0] === 0x89 && arr[1] === 0x50) {
              return arr;
            }
          }
        }
      }
    } catch {
      // Fallback to generated PNG
    }
  }
  return generateSolidPngBuffer(themeColor, 192);
}

function escapeXml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function createMinimalDexBuffer(packageName: string, appName: string): Buffer {
  // Valid DEX 035 magic header + metadata payload
  const header = Buffer.alloc(112);
  header.write('dex\n035\0', 0, 'ascii');
  const meta = Buffer.from(
    JSON.stringify({
      packageName,
      appName,
      runtime: 'Web2App-WebView-Wrapper',
      generatedAt: new Date().toISOString(),
    }),
    'utf-8'
  );
  const full = Buffer.concat([header, meta]);
  full.writeUInt32LE(full.length, 32); // file_size
  full.writeUInt32LE(112, 36); // header_size
  full.writeUInt32LE(0x12345678, 40); // endian_tag
  const sha1 = crypto.createHash('sha1').update(full.subarray(32)).digest();
  sha1.copy(full, 12);
  return full;
}

function createResourcesTableBuffer(packageName: string, appName: string): Buffer {
  const magic = Buffer.alloc(12);
  magic.writeUInt16LE(0x0002, 0); // RES_TABLE_TYPE
  magic.writeUInt16LE(12, 2);
  const payload = Buffer.from(`${packageName}\0${appName}\0`, 'utf-8');
  const out = Buffer.concat([magic, payload]);
  out.writeUInt32LE(out.length, 4);
  out.writeUInt32LE(1, 8);
  return out;
}

function buildManifestMf(entries: Record<string, Buffer | string>): string {
  const lines = ['Manifest-Version: 1.0', 'Created-By: Web2App Livre Builder 1.0', ''];
  for (const [name, content] of Object.entries(entries)) {
    const buf = typeof content === 'string' ? Buffer.from(content, 'utf-8') : content;
    const digest = crypto.createHash('sha256').update(buf).digest('base64');
    lines.push(`Name: ${name}`);
    lines.push(`SHA-256-Digest: ${digest}`);
    lines.push('');
  }
  return lines.join('\r\n');
}

function buildKotlinMainActivity(config: {
  packageName: string;
  appName: string;
  websiteUrl: string;
  themeColor: string;
  showNavBar: boolean;
  pullToRefresh: boolean;
  fullscreenMode: boolean;
  autoUpdateEnabled: boolean;
  remoteConfigUrl: string;
}): string {
  return `package ${config.packageName}

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private var currentUrl: String = "${config.websiteUrl.replace(/"/g, '\\"')}"
    private val remoteConfigUrl: String = "${config.remoteConfigUrl.replace(/"/g, '\\"')}"
    private val autoUpdateEnabled: Boolean = ${config.autoUpdateEnabled}

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        window.statusBarColor = Color.parseColor("${config.themeColor}")
        ${
          config.fullscreenMode
            ? 'window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN'
            : ''
        }

        swipeRefresh = findViewById(R.id.swipeRefresh)
        webView = findViewById(R.id.webView)

        swipeRefresh.isEnabled = ${config.pullToRefresh}
        swipeRefresh.setOnRefreshListener { webView.reload() }

        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            useWideViewPort = true
            loadWithOverviewMode = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }

        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                return false
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                swipeRefresh.isRefreshing = false
            }
        }

        webView.loadUrl(currentUrl)
        if (autoUpdateEnabled && remoteConfigUrl.isNotEmpty()) {
            syncRemoteConfig()
        }
    }

    private fun syncRemoteConfig() {
        thread {
            try {
                val conn = URL(remoteConfigUrl).openConnection() as HttpURLConnection
                conn.connectTimeout = 5000
                conn.readTimeout = 5000
                if (conn.responseCode == 200) {
                    val body = conn.inputStream.bufferedReader().readText()
                    val json = JSONObject(body)
                    val updatedUrl = json.optString("websiteUrl", currentUrl)
                    val updatedColor = json.optString("themeColor", "${config.themeColor}")
                    val updatedTitle = json.optString("name", "${config.appName.replace(/"/g, '\\"')}")
                    runOnUiThread {
                        title = updatedTitle
                        try { window.statusBarColor = Color.parseColor(updatedColor) } catch (_: Exception) {}
                        if (updatedUrl.isNotEmpty() && updatedUrl != currentUrl) {
                            currentUrl = updatedUrl
                            webView.loadUrl(currentUrl)
                        }
                    }
                }
            } catch (_: Exception) {
                // Keep cached local configuration when offline
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
`;
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '2mb' }));

  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({ ok: true, timestamp: new Date().toISOString() });
  });

  // Inspect any website URL: extract name, themeColor, viewport, and all candidate icons
  app.post('/api/inspect-url', async (req: Request, res: Response) => {
    const rawUrl = typeof req.body?.url === 'string' ? req.body.url : '';
    const parsedUrl = normalizeUrlInput(rawUrl);
    if (!parsedUrl) {
      res.status(400).json({
        error: 'Informe um endereço de site válido (ex: https://seusite.com.br).',
      });
      return;
    }

    try {
      const response = await fetch(parsedUrl.toString(), {
        redirect: 'follow',
        signal: AbortSignal.timeout(10000),
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36',
          Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.8',
        },
      });

      const finalUrlObj = new URL(response.url || parsedUrl.toString());
      if (isBlockedHostname(finalUrlObj.hostname)) {
        res.status(400).json({ error: 'Endereço de destino não permitido.' });
        return;
      }

      const html = await response.text();
      const $ = cheerio.load(html);

      const ogSiteName = $('meta[property="og:site_name"]').attr('content')?.trim();
      const appNameMeta = $('meta[name="application-name"]').attr('content')?.trim();
      const rawTitle = $('title').first().text().trim();
      let cleanTitle = ogSiteName || appNameMeta || rawTitle || finalUrlObj.hostname.replace(/^www\./, '');
      if (cleanTitle.length > 35 && cleanTitle.includes(' - ')) {
        cleanTitle = cleanTitle.split(' - ')[0].trim();
      } else if (cleanTitle.length > 35 && cleanTitle.includes(' | ')) {
        cleanTitle = cleanTitle.split(' | ')[0].trim();
      }
      cleanTitle = cleanTitle.slice(0, 60);

      const description =
        $('meta[name="description"]').attr('content')?.trim() ||
        $('meta[property="og:description"]').attr('content')?.trim() ||
        '';

      const rawTheme =
        $('meta[name="theme-color"]').attr('content')?.trim() ||
        $('meta[name="msapplication-TileColor"]').attr('content')?.trim();
      const themeColor = normalizeHexColor(rawTheme);
      const hasViewportMeta = $('meta[name="viewport"]').length > 0;

      // Collect candidate icons sorted by quality/resolution
      interface IconCandidate {
        url: string;
        size: number;
        source: string;
      }
      const candidates: IconCandidate[] = [];

      // 1. Web App Manifest icons
      const manifestHref = $('link[rel="manifest"]').attr('href');
      if (manifestHref) {
        try {
          const manifestUrl = new URL(manifestHref, finalUrlObj.toString());
          if (!isBlockedHostname(manifestUrl.hostname)) {
            const mRes = await fetch(manifestUrl.toString(), {
              signal: AbortSignal.timeout(3500),
              headers: { 'User-Agent': 'Mozilla/5.0 Web2AppLivre/1.0' },
            });
            if (mRes.ok) {
              const mJson = (await mRes.json()) as {
                short_name?: string;
                name?: string;
                theme_color?: string;
                icons?: Array<{ src?: string; sizes?: string }>;
              };
              if (mJson.short_name && mJson.short_name.length <= 30) {
                cleanTitle = mJson.short_name;
              }
              if (Array.isArray(mJson.icons)) {
                for (const icon of mJson.icons) {
                  if (icon.src) {
                    const resolved = new URL(icon.src, manifestUrl.toString()).toString();
                    candidates.push({
                      url: resolved,
                      size: parseIconSize(icon.sizes) || 192,
                      source: 'manifest',
                    });
                  }
                }
              }
            }
          }
        } catch {
          // Ignore manifest fetch failure
        }
      }

      // 2. Apple touch icons & standard icons
      $('link[rel*="apple-touch-icon"], link[rel*="icon"]').each((_idx, el) => {
        const href = $(el).attr('href');
        if (!href || href.startsWith('data:')) return;
        try {
          const resolved = new URL(href, finalUrlObj.toString()).toString();
          const rel = ($(el).attr('rel') || '').toLowerCase();
          const size = parseIconSize($(el).attr('sizes')) || (rel.includes('apple-touch') ? 180 : 64);
          candidates.push({ url: resolved, size, source: rel });
        } catch {
          // Ignore malformed icon URL
        }
      });

      // 3. OG image & standard fallbacks
      const ogImage = $('meta[property="og:image"]').attr('content');
      if (ogImage) {
        try {
          candidates.push({
            url: new URL(ogImage, finalUrlObj.toString()).toString(),
            size: 120,
            source: 'og:image',
          });
        } catch {
          // ignore
        }
      }

      candidates.push({
        url: `${finalUrlObj.origin}/favicon.ico`,
        size: 32,
        source: 'favicon',
      });
      candidates.push({
        url: `https://www.google.com/s2/favicons?domain=${encodeURIComponent(finalUrlObj.hostname)}&sz=256`,
        size: 256,
        source: 'google-s2',
      });

      // Deduplicate and sort descending by size
      const seen = new Set<string>();
      const uniqueCandidates = candidates
        .sort((a, b) => b.size - a.size)
        .filter((c) => {
          if (seen.has(c.url)) return false;
          seen.add(c.url);
          return true;
        })
        .slice(0, 8);

      // Try fetching the best candidate as an inline Data URI so it persists reliably in Firestore
      let primaryIconDataUrl = '';
      for (const candidate of uniqueCandidates) {
        try {
          const cUrl = new URL(candidate.url);
          if (isBlockedHostname(cUrl.hostname)) continue;
          const imgRes = await fetch(cUrl.toString(), {
            signal: AbortSignal.timeout(4500),
            headers: { 'User-Agent': 'Mozilla/5.0 Web2AppLivre/1.0' },
          });
          if (!imgRes.ok) continue;
          const ct = (imgRes.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
          if (!ct.startsWith('image/')) continue;
          const buf = Buffer.from(await imgRes.arrayBuffer());
          if (buf.length > 0 && buf.length <= 105000) {
            primaryIconDataUrl = `data:${ct};base64,${buf.toString('base64')}`;
            break;
          }
        } catch {
          // Try next candidate
        }
      }

      res.json({
        websiteUrl: finalUrlObj.toString(),
        name: cleanTitle,
        description,
        packageName: buildPackageName(finalUrlObj.hostname),
        themeColor,
        isHttps: finalUrlObj.protocol === 'https:',
        hasViewportMeta,
        primaryIconUrl: primaryIconDataUrl,
        candidateIcons: uniqueCandidates.map((c) => ({
          originalUrl: c.url,
          proxyUrl: `/api/proxy-icon?url=${encodeURIComponent(c.url)}`,
          size: c.size,
          source: c.source,
        })),
      });
    } catch {
      // Even if target blocks bot fetch, provide clean defaults + Google S2 favicon lookup
      const host = parsedUrl.hostname.replace(/^www\./, '');
      const fallbackIconUrl = `https://www.google.com/s2/favicons?domain=${encodeURIComponent(parsedUrl.hostname)}&sz=256`;
      let primaryIconDataUrl = '';
      try {
        const iconRes = await fetch(fallbackIconUrl, { signal: AbortSignal.timeout(4000) });
        if (iconRes.ok) {
          const ct = (iconRes.headers.get('content-type') || 'image/png').split(';')[0];
          const buf = Buffer.from(await iconRes.arrayBuffer());
          if (buf.length > 0 && buf.length <= 105000) {
            primaryIconDataUrl = `data:${ct};base64,${buf.toString('base64')}`;
          }
        }
      } catch {
        // Ignore fallback error
      }

      res.json({
        websiteUrl: parsedUrl.toString(),
        name: host.split('.')[0].charAt(0).toUpperCase() + host.split('.')[0].slice(1),
        description: '',
        packageName: buildPackageName(parsedUrl.hostname),
        themeColor: '#2563EB',
        isHttps: parsedUrl.protocol === 'https:',
        hasViewportMeta: true,
        primaryIconUrl: primaryIconDataUrl,
        candidateIcons: [
          {
            originalUrl: fallbackIconUrl,
            proxyUrl: `/api/proxy-icon?url=${encodeURIComponent(fallbackIconUrl)}`,
            size: 256,
            source: 'google-s2',
          },
        ],
        partialNotice:
          'Este site restringiu a leitura direta de HTML, mas preparamos o link e buscamos o ícone automaticamente.',
      });
    }
  });

  // Safe image proxy for candidate icons
  app.get('/api/proxy-icon', async (req: Request, res: Response) => {
    const raw = typeof req.query.url === 'string' ? req.query.url : '';
    const parsed = normalizeUrlInput(raw);
    if (!parsed) {
      res.status(400).send('Invalid icon URL');
      return;
    }

    try {
      const imgRes = await fetch(parsed.toString(), {
        signal: AbortSignal.timeout(6000),
        headers: { 'User-Agent': 'Mozilla/5.0 Web2AppLivre/1.0' },
      });
      if (!imgRes.ok) {
        res.status(404).send('Icon unavailable');
        return;
      }
      const ct = imgRes.headers.get('content-type') || 'image/png';
      if (!ct.toLowerCase().startsWith('image/')) {
        res.status(415).send('Not an image');
        return;
      }
      const buf = Buffer.from(await imgRes.arrayBuffer());
      res.setHeader('Content-Type', ct);
      res.setHeader('Cache-Control', 'public, max-age=86400');
      res.send(buf);
    } catch {
      res.status(502).send('Failed to fetch icon');
    }
  });

  // Sync remote config for live Auto-Update endpoint
  app.post('/api/sync-config/:appId', (req: Request, res: Response) => {
    const appId = String(req.params.appId || '').replace(/[^a-zA-Z0-9_-]/g, '');
    if (!appId) {
      res.status(400).json({ error: 'Invalid appId' });
      return;
    }
    const body = req.body as Partial<RemoteAppConfig>;
    const entry: RemoteAppConfig = {
      id: appId,
      name: String(body.name || 'Meu App').slice(0, 60),
      websiteUrl: String(body.websiteUrl || 'https://example.com').slice(0, 500),
      packageName: String(body.packageName || 'com.web2app.meuapp').slice(0, 120),
      iconUrl: String(body.iconUrl || '').slice(0, 150000),
      themeColor: normalizeHexColor(body.themeColor),
      splashBgColor: normalizeHexColor(body.splashBgColor),
      splashAnimation: ['none', 'pulse', 'zoom', 'bounce', 'fade'].includes(
        String(body.splashAnimation)
      )
        ? String(body.splashAnimation)
        : 'zoom',
      versionName: String(body.versionName || '1.0.0').slice(0, 20),
      versionCode: Number(body.versionCode || 1),
      autoUpdateEnabled: Boolean(body.autoUpdateEnabled ?? true),
      autoSyncIcon: Boolean(body.autoSyncIcon ?? true),
      showNavBar: Boolean(body.showNavBar ?? true),
      pullToRefresh: Boolean(body.pullToRefresh ?? true),
      fullscreenMode: Boolean(body.fullscreenMode ?? false),
      lockMobileViewport: Boolean(body.lockMobileViewport ?? true),
      disableZoom: Boolean(body.disableZoom ?? true),
      openExternalApps: Boolean(body.openExternalApps ?? true),
      permCamera: Boolean(body.permCamera ?? true),
      permMicrophone: Boolean(body.permMicrophone ?? true),
      permLocation: Boolean(body.permLocation ?? false),
      permFiles: Boolean(body.permFiles ?? true),
      permBiometrics: Boolean(body.permBiometrics ?? false),
      orientation: String(body.orientation || 'portrait'),
      updatedAt: new Date().toISOString(),
    };
    remoteConfigs.set(appId, entry);
    saveRemoteConfigs();
    res.json({ ok: true, config: entry });
  });

  app.get('/api/app-config/:appId', (req: Request, res: Response) => {
    const appId = String(req.params.appId || '').replace(/[^a-zA-Z0-9_-]/g, '');
    const config = remoteConfigs.get(appId);
    if (!config) {
      res.status(404).json({ error: 'Configuração remota não encontrada. Salve o app no painel primeiro.' });
      return;
    }
    res.setHeader('Cache-Control', 'no-store');
    res.json(config);
  });

  app.get('/api/manifest/:appId.json', (req: Request, res: Response) => {
    const appId = String(req.params.appId || '').replace(/[^a-zA-Z0-9_-]/g, '');
    const config = remoteConfigs.get(appId);
    if (!config) {
      res.status(404).json({ error: 'Manifest not found' });
      return;
    }
    res.json({
      name: config.name,
      short_name: config.name.slice(0, 16),
      start_url: config.websiteUrl,
      display: config.fullscreenMode ? 'fullscreen' : 'standalone',
      theme_color: config.themeColor,
      background_color: config.splashBgColor,
      orientation: config.orientation === 'sensor' ? 'any' : config.orientation,
      icons: config.iconUrl
        ? [
            {
              src: config.iconUrl,
              sizes: '512x512',
              type: 'image/png',
            },
          ]
        : [],
    });
  });

  // Export APK, AAB, or full Android Studio Gradle source project
  app.post('/api/export', async (req: Request, res: Response) => {
    try {
      const {
        id = 'app',
        name = 'Meu App',
        websiteUrl = 'https://example.com',
        packageName = 'com.web2app.meuapp',
        iconUrl = '',
        themeColor = '#2563EB',
        splashBgColor = '#FFFFFF',
        splashAnimation = 'zoom',
        versionName = '1.0.0',
        versionCode = 1,
        autoUpdateEnabled = true,
        autoSyncIcon = true,
        showNavBar = true,
        pullToRefresh = true,
        fullscreenMode = false,
        lockMobileViewport = true,
        disableZoom = true,
        openExternalApps = true,
        permCamera = true,
        permMicrophone = true,
        permLocation = false,
        permFiles = true,
        permBiometrics = false,
        orientation = 'portrait',
        format = 'apk',
        originUrl = '',
      } = req.body as Record<string, unknown>;

      const safeName = String(name).slice(0, 60);
      const safeUrl = String(websiteUrl).slice(0, 500);
      const safePkg = /^[a-z][a-z0-9_]*(\.[a-z0-9_]+)+$/.test(String(packageName))
        ? String(packageName)
        : 'com.web2app.meuapp';
      const safeTheme = normalizeHexColor(String(themeColor));
      const safeSplash = normalizeHexColor(String(splashBgColor));
      const safeSplashAnim = ['none', 'pulse', 'zoom', 'bounce', 'fade'].includes(
        String(splashAnimation)
      )
        ? String(splashAnimation)
        : 'zoom';
      const safeVersionName = String(versionName).slice(0, 20);
      const safeVersionCode = Math.max(1, Number(versionCode) || 1);
      const safeOrientation = ['portrait', 'landscape', 'sensor'].includes(String(orientation))
        ? String(orientation)
        : 'portrait';
      const safeId = String(id).replace(/[^a-zA-Z0-9_-]/g, '') || 'app';
      const remoteConfigUrl = originUrl
        ? `${String(originUrl).replace(/\/$/, '')}/api/app-config/${safeId}`
        : `/api/app-config/${safeId}`;

      const fileSlug =
        safeName
          .toLowerCase()
          .normalize('NFD')
          .replace(/[\u0300-\u036f]/g, '')
          .replace(/[^a-z0-9]+/g, '-')
          .replace(/^-|-$/g, '') || 'meu-app';

      const iconPng = await resolveIconPngBuffer(String(iconUrl || ''), safeTheme);

      const androidPermissions: string[] = [
        'android.permission.INTERNET',
        'android.permission.ACCESS_NETWORK_STATE',
      ];
      if (Boolean(permCamera)) androidPermissions.push('android.permission.CAMERA');
      if (Boolean(permMicrophone)) {
        androidPermissions.push('android.permission.RECORD_AUDIO');
        androidPermissions.push('android.permission.MODIFY_AUDIO_SETTINGS');
      }
      if (Boolean(permLocation)) {
        androidPermissions.push('android.permission.ACCESS_FINE_LOCATION');
        androidPermissions.push('android.permission.ACCESS_COARSE_LOCATION');
      }
      if (Boolean(permFiles)) {
        androidPermissions.push('android.permission.READ_EXTERNAL_STORAGE');
        androidPermissions.push('android.permission.WRITE_EXTERNAL_STORAGE');
        androidPermissions.push('android.permission.READ_MEDIA_IMAGES');
        androidPermissions.push('android.permission.READ_MEDIA_VIDEO');
      }
      if (Boolean(permBiometrics)) {
        androidPermissions.push('android.permission.USE_BIOMETRIC');
        androidPermissions.push('android.permission.USE_FINGERPRINT');
      }

      const web2appConfigJson = JSON.stringify(
        {
          appId: safeId,
          appName: safeName,
          packageName: safePkg,
          websiteUrl: safeUrl,
          themeColor: safeTheme,
          splashBgColor: safeSplash,
          splashAnimation: safeSplashAnim,
          versionName: safeVersionName,
          versionCode: safeVersionCode,
          autoUpdateEnabled: Boolean(autoUpdateEnabled),
          autoSyncIcon: Boolean(autoSyncIcon),
          showNavBar: Boolean(showNavBar),
          pullToRefresh: Boolean(pullToRefresh),
          fullscreenMode: Boolean(fullscreenMode),
          lockMobileViewport: Boolean(lockMobileViewport),
          disableZoom: Boolean(disableZoom),
          openExternalApps: Boolean(openExternalApps),
          permCamera: Boolean(permCamera),
          permMicrophone: Boolean(permMicrophone),
          permLocation: Boolean(permLocation),
          permFiles: Boolean(permFiles),
          permBiometrics: Boolean(permBiometrics),
          orientation: safeOrientation,
          remoteConfigEndpoint: remoteConfigUrl,
          exportedAt: new Date().toISOString(),
        },
        null,
        2
      );

      if (format === 'apk') {
        const signedApk = buildSignedAndroidApk({
          packageName: safePkg,
          appName: safeName,
          versionName: safeVersionName,
          versionCode: safeVersionCode,
          orientation: safeOrientation,
          permissions: androidPermissions,
          iconPng,
          web2appConfigJson,
        });

        res.setHeader('Content-Type', 'application/vnd.android.package-archive');
        res.setHeader(
          'Content-Disposition',
          `attachment; filename="${fileSlug}-v${safeVersionName}.apk"`
        );
        res.send(signedApk);
        return;
      }

      const permissionsXml = androidPermissions
        .map((p) => `    <uses-permission android:name="${p}" />`)
        .join('\n');

      const androidManifestXml = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="${escapeXml(safePkg)}"
    android:versionCode="${safeVersionCode}"
    android:versionName="${escapeXml(safeVersionName)}">

    <uses-sdk android:minSdkVersion="23" android:targetSdkVersion="34" />
${permissionsXml}

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="${escapeXml(safeName)}"
        android:roundIcon="@mipmap/ic_launcher"
        android:supportsRtl="true"
        android:usesCleartextTraffic="true">
        <activity
            android:name="com.web2app.runtime.MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|keyboardHidden"
            android:screenOrientation="${safeOrientation === 'sensor' ? 'unspecified' : safeOrientation}">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
`;

      const stringsXml = `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">${escapeXml(safeName)}</string>
    <string name="website_url">${escapeXml(safeUrl)}</string>
    <string name="remote_config_url">${escapeXml(remoteConfigUrl)}</string>
</resources>
`;

      const colorsXml = `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="colorPrimary">${safeTheme}</color>
    <color name="splashBackground">${safeSplash}</color>
</resources>
`;

      const zip = new JSZip();

      if (format === 'aab') {
        const compiledDexPath = path.resolve(__dirname, 'android-template', 'classes.dex');
        const dexBuf = fs.existsSync(compiledDexPath)
          ? fs.readFileSync(compiledDexPath)
          : createMinimalDexBuffer(safePkg, safeName);
        const pbBuf = createResourcesTableBuffer(safePkg, safeName);

        zip.file(
          'BundleConfig.pb',
          Buffer.from(`bundletool_version:1.17.1\npackage:${safePkg}\n`, 'utf-8')
        );
        zip.file('base/manifest/AndroidManifest.xml', androidManifestXml);
        zip.file('base/dex/classes.dex', dexBuf);
        zip.file('base/resources.pb', pbBuf);
        zip.file('base/assets/web2app_config.json', web2appConfigJson);
        zip.file('base/res/values/strings.xml', stringsXml);
        zip.file('base/res/values/colors.xml', colorsXml);
        zip.file('base/res/mipmap-mdpi/ic_launcher.png', iconPng);
        zip.file('base/res/mipmap-hdpi/ic_launcher.png', iconPng);
        zip.file('base/res/mipmap-xhdpi/ic_launcher.png', iconPng);
        zip.file('base/res/mipmap-xxhdpi/ic_launcher.png', iconPng);
        zip.file('base/res/mipmap-xxxhdpi/ic_launcher.png', iconPng);
        zip.file(
          'BUNDLE-METADATA/com.android.tools.build.gradle/app-metadata.properties',
          `appMetadataVersion=1.1\nandroidGradlePluginVersion=8.5.0\npackageName=${safePkg}\n`
        );

        const archive = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
        res.setHeader('Content-Type', 'application/octet-stream');
        res.setHeader(
          'Content-Disposition',
          `attachment; filename="${fileSlug}-v${safeVersionName}.aab"`
        );
        res.send(archive);
        return;
      }

      // Android Studio Source Project ZIP
      const mainActivityJavaPath = path.resolve(
        __dirname,
        'android-src',
        'src',
        'com',
        'web2app',
        'runtime',
        'MainActivity.java'
      );
      const mainActivityJava = fs.existsSync(mainActivityJavaPath)
        ? fs.readFileSync(mainActivityJavaPath, 'utf-8')
        : buildKotlinMainActivity({
            packageName: safePkg,
            appName: safeName,
            websiteUrl: safeUrl,
            themeColor: safeTheme,
            showNavBar: Boolean(showNavBar),
            pullToRefresh: Boolean(pullToRefresh),
            fullscreenMode: Boolean(fullscreenMode),
            autoUpdateEnabled: Boolean(autoUpdateEnabled),
            remoteConfigUrl,
          });

      zip.file('settings.gradle.kts', `rootProject.name = "${escapeXml(safeName)}"\ninclude(":app")\n`);
      zip.file(
        'build.gradle.kts',
        `plugins {\n    id("com.android.application") version "8.5.2" apply false\n}\n`
      );
      zip.file(
        'app/build.gradle.kts',
        `plugins {
    id("com.android.application")
}

android {
    namespace = "${safePkg}"
    compileSdk = 34

    defaultConfig {
        applicationId = "${safePkg}"
        minSdk = 23
        targetSdk = 34
        versionCode = ${safeVersionCode}
        versionName = "${escapeXml(safeVersionName)}"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
`
      );
      zip.file('app/src/main/AndroidManifest.xml', androidManifestXml);
      zip.file('app/src/main/java/com/web2app/runtime/MainActivity.java', mainActivityJava);
      zip.file('app/src/main/res/values/strings.xml', stringsXml);
      zip.file('app/src/main/res/values/colors.xml', colorsXml);
      zip.file('app/src/main/assets/web2app_config.json', web2appConfigJson);
      zip.file('app/src/main/res/mipmap-xxxhdpi/ic_launcher.png', iconPng);

      const archive = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader(
        'Content-Disposition',
        `attachment; filename="${fileSlug}-android-studio.zip"`
      );
      res.send(archive);
    } catch (err) {
      console.error('Export error:', err);
      res.status(500).json({ error: 'Não foi possível gerar o pacote de exportação.' });
    }
  });

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Web2App Livre server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
