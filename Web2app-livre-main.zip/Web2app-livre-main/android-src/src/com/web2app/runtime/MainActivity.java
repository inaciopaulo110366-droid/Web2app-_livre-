package com.web2app.runtime;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.app.KeyguardManager;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.BounceInterpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_RUNTIME_PERMS = 1001;
    private static final int REQ_FILE_CHOOSER = 1002;
    private static final int REQ_BIOMETRICS = 1003;
    private static final String MOBILE_USER_AGENT =
            "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36";

    private WebView webView;
    private FrameLayout splashOverlay;
    private ImageView splashIcon;
    private TextView splashTitle;
    private ProgressBar loadingBar;
    private LinearLayout topHeaderBar;
    private TextView headerTitleView;

    private ValueCallback<Uri[]> filePathCallback;
    private PermissionRequest pendingWebPermissionRequest;
    private GeolocationPermissions.Callback pendingGeoCallback;
    private String pendingGeoOrigin;

    private String appName = "Web2App";
    private String websiteUrl = "https://example.com";
    private String homeHost = "";
    private String themeColor = "#2563EB";
    private String splashBgColor = "#FFFFFF";
    private String splashAnimation = "zoom";
    private String remoteConfigEndpoint = "";
    private String orientation = "portrait";

    private boolean showNavBar = true;
    private boolean pullToRefresh = true;
    private boolean fullscreenMode = false;
    private boolean lockMobileViewport = true;
    private boolean disableZoom = true;
    private boolean openExternalApps = true;
    private boolean autoUpdateEnabled = true;

    private boolean permCamera = true;
    private boolean permMicrophone = true;
    private boolean permLocation = false;
    private boolean permFiles = true;
    private boolean permBiometrics = false;

    private boolean splashDismissed = false;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        loadLocalConfig();
        applyOrientation();
        buildUi();
        applyThemeColors();
        configureWebView();
        startSplashAnimation();
        requestStartupPermissions();

        if (permBiometrics) {
            promptBiometricsThenLoad();
        } else {
            loadInitialSite();
        }

        if (autoUpdateEnabled && remoteConfigEndpoint.startsWith("http")) {
            syncRemoteConfigAsync();
        }
    }

    private void loadLocalConfig() {
        try {
            InputStream is = getAssets().open("web2app_config.json");
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            reader.close();
            JSONObject json = new JSONObject(sb.toString());
            applyJsonConfig(json, false);
        } catch (Exception ignored) {
        }
    }

    private void applyJsonConfig(JSONObject json, boolean isRemoteUpdate) {
        String newName = json.optString("appName", json.optString("name", appName));
        String newUrl = json.optString("websiteUrl", websiteUrl);
        if (!newName.isEmpty()) appName = newName;
        if (!newUrl.isEmpty()) {
            websiteUrl = newUrl;
            try {
                Uri parsed = Uri.parse(websiteUrl);
                if (parsed.getHost() != null) {
                    homeHost = parsed.getHost().toLowerCase();
                }
            } catch (Exception ignored) {
            }
        }
        themeColor = json.optString("themeColor", themeColor);
        splashBgColor = json.optString("splashBgColor", splashBgColor);
        splashAnimation = json.optString("splashAnimation", splashAnimation);
        orientation = json.optString("orientation", orientation);
        showNavBar = json.optBoolean("showNavBar", showNavBar);
        pullToRefresh = json.optBoolean("pullToRefresh", pullToRefresh);
        fullscreenMode = json.optBoolean("fullscreenMode", fullscreenMode);
        lockMobileViewport = json.optBoolean("lockMobileViewport", lockMobileViewport);
        disableZoom = json.optBoolean("disableZoom", disableZoom);
        openExternalApps = json.optBoolean("openExternalApps", openExternalApps);
        autoUpdateEnabled = json.optBoolean("autoUpdateEnabled", autoUpdateEnabled);
        permCamera = json.optBoolean("permCamera", permCamera);
        permMicrophone = json.optBoolean("permMicrophone", permMicrophone);
        permLocation = json.optBoolean("permLocation", permLocation);
        permFiles = json.optBoolean("permFiles", permFiles);
        permBiometrics = json.optBoolean("permBiometrics", permBiometrics);
        if (!isRemoteUpdate) {
            remoteConfigEndpoint = json.optString("remoteConfigEndpoint", "");
        }
    }

    private void applyOrientation() {
        if ("portrait".equals(orientation)) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        } else if ("landscape".equals(orientation)) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);
        }
    }

    private int dp(int value) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics()
        );
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        LinearLayout mainCol = new LinearLayout(this);
        mainCol.setOrientation(LinearLayout.VERTICAL);
        mainCol.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        // Optional Native Top App Bar
        topHeaderBar = new LinearLayout(this);
        topHeaderBar.setOrientation(LinearLayout.HORIZONTAL);
        topHeaderBar.setGravity(Gravity.CENTER_VERTICAL);
        topHeaderBar.setPadding(dp(16), dp(8), dp(12), dp(8));
        topHeaderBar.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(52)
        ));

        headerTitleView = new TextView(this);
        headerTitleView.setText(appName);
        headerTitleView.setTextColor(Color.WHITE);
        headerTitleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        headerTitleView.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
        );
        topHeaderBar.addView(headerTitleView, titleParams);

        if (pullToRefresh) {
            TextView refreshBtn = new TextView(this);
            refreshBtn.setText("↻");
            refreshBtn.setTextColor(Color.WHITE);
            refreshBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
            refreshBtn.setPadding(dp(12), dp(4), dp(12), dp(4));
            refreshBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (webView != null) webView.reload();
                }
            });
            topHeaderBar.addView(refreshBtn);
        }

        topHeaderBar.setVisibility(showNavBar ? View.VISIBLE : View.GONE);
        mainCol.addView(topHeaderBar);

        loadingBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        loadingBar.setMax(100);
        loadingBar.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(3)
        ));
        loadingBar.setVisibility(View.GONE);
        mainCol.addView(loadingBar);

        webView = new WebView(this);
        webView.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
        ));
        mainCol.addView(webView);
        root.addView(mainCol);

        // Animated Splash Screen Overlay
        splashOverlay = new FrameLayout(this);
        splashOverlay.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        try {
            splashOverlay.setBackgroundColor(Color.parseColor(splashBgColor));
        } catch (Exception e) {
            splashOverlay.setBackgroundColor(Color.WHITE);
        }

        LinearLayout splashCenter = new LinearLayout(this);
        splashCenter.setOrientation(LinearLayout.VERTICAL);
        splashCenter.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams centerParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
        );

        splashIcon = new ImageView(this);
        int iconResId = getApplicationInfo().icon;
        if (iconResId != 0) {
            splashIcon.setImageResource(iconResId);
        }
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(96), dp(96));
        iconParams.bottomMargin = dp(18);
        splashCenter.addView(splashIcon, iconParams);

        splashTitle = new TextView(this);
        splashTitle.setText(appName);
        splashTitle.setTextColor(isDarkColor(splashBgColor) ? Color.WHITE : Color.parseColor("#0F172A"));
        splashTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        splashTitle.setTypeface(Typeface.DEFAULT_BOLD);
        splashTitle.setGravity(Gravity.CENTER);
        splashCenter.addView(splashTitle);

        splashOverlay.addView(splashCenter, centerParams);
        root.addView(splashOverlay);

        setContentView(root);
    }

    private boolean isDarkColor(String hex) {
        try {
            int color = Color.parseColor(hex);
            double luminance = (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255.0;
            return luminance < 0.5;
        } catch (Exception e) {
            return false;
        }
    }

    private void applyThemeColors() {
        try {
            int parsedColor = Color.parseColor(themeColor);
            if (topHeaderBar != null) {
                topHeaderBar.setBackgroundColor(parsedColor);
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                Window window = getWindow();
                window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                window.setStatusBarColor(parsedColor);
            }
        } catch (Exception ignored) {
        }
        if (fullscreenMode) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            );
        }
    }

    private void startSplashAnimation() {
        if (splashIcon == null || "none".equals(splashAnimation)) {
            mainHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    dismissSplash();
                }
            }, 1800);
            return;
        }

        Animation anim;
        if ("pulse".equals(splashAnimation)) {
            ScaleAnimation scale = new ScaleAnimation(
                    0.90f, 1.08f, 0.90f, 1.08f,
                    Animation.RELATIVE_TO_SELF, 0.5f,
                    Animation.RELATIVE_TO_SELF, 0.5f
            );
            scale.setDuration(650);
            scale.setRepeatMode(Animation.REVERSE);
            scale.setRepeatCount(Animation.INFINITE);
            anim = scale;
        } else if ("bounce".equals(splashAnimation)) {
            TranslateAnimation trans = new TranslateAnimation(0f, 0f, -dp(70), 0f);
            trans.setDuration(850);
            trans.setInterpolator(new BounceInterpolator());
            anim = trans;
        } else if ("fade".equals(splashAnimation)) {
            AlphaAnimation fade = new AlphaAnimation(0f, 1f);
            fade.setDuration(700);
            anim = fade;
        } else {
            // Default: zoom
            AnimationSet set = new AnimationSet(true);
            ScaleAnimation zoom = new ScaleAnimation(
                    0.45f, 1.0f, 0.45f, 1.0f,
                    Animation.RELATIVE_TO_SELF, 0.5f,
                    Animation.RELATIVE_TO_SELF, 0.5f
            );
            zoom.setDuration(650);
            AlphaAnimation alpha = new AlphaAnimation(0f, 1f);
            alpha.setDuration(550);
            set.addAnimation(zoom);
            set.addAnimation(alpha);
            anim = set;
        }

        splashIcon.startAnimation(anim);
        mainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                dismissSplash();
            }
        }, 2200);
    }

    private void dismissSplash() {
        if (splashDismissed || splashOverlay == null) return;
        splashDismissed = true;
        AlphaAnimation fadeOut = new AlphaAnimation(1f, 0f);
        fadeOut.setDuration(300);
        fadeOut.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {}
            @Override
            public void onAnimationEnd(Animation animation) {
                splashOverlay.setVisibility(View.GONE);
            }
            @Override
            public void onAnimationRepeat(Animation animation) {}
        });
        splashOverlay.startAnimation(fadeOut);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(false);

        // Mobile viewport enforcement - never render in desktop mode
        settings.setUserAgentString(MOBILE_USER_AGENT);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setTextZoom(100);

        if (disableZoom) {
            settings.setSupportZoom(false);
            settings.setBuiltInZoomControls(false);
            settings.setDisplayZoomControls(false);
        } else {
            settings.setSupportZoom(true);
            settings.setBuiltInZoomControls(true);
            settings.setDisplayZoomControls(false);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        }
        CookieManager.getInstance().setAcceptCookie(true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrlNavigation(url);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (lockMobileViewport || disableZoom) {
                    injectMobileViewportLock();
                }
                mainHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        dismissSplash();
                    }
                }, 400);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (loadingBar != null) {
                    if (newProgress < 100) {
                        loadingBar.setVisibility(View.VISIBLE);
                        loadingBar.setProgress(newProgress);
                    } else {
                        loadingBar.setVisibility(View.GONE);
                    }
                }
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        List<String> granted = new ArrayList<>();
                        List<String> neededPerms = new ArrayList<>();
                        for (String res : request.getResources()) {
                            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res) && permCamera) {
                                granted.add(res);
                                if (!hasPerm(Manifest.permission.CAMERA)) {
                                    neededPerms.add(Manifest.permission.CAMERA);
                                }
                            } else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res) && permMicrophone) {
                                granted.add(res);
                                if (!hasPerm(Manifest.permission.RECORD_AUDIO)) {
                                    neededPerms.add(Manifest.permission.RECORD_AUDIO);
                                }
                            }
                        }
                        if (granted.isEmpty()) {
                            request.deny();
                            return;
                        }
                        if (neededPerms.isEmpty()) {
                            request.grant(granted.toArray(new String[0]));
                        } else {
                            pendingWebPermissionRequest = request;
                            requestRuntimePermissions(neededPerms.toArray(new String[0]));
                        }
                    }
                });
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (!permLocation) {
                    callback.invoke(origin, false, false);
                    return;
                }
                if (hasPerm(Manifest.permission.ACCESS_FINE_LOCATION) || hasPerm(Manifest.permission.ACCESS_COARSE_LOCATION)) {
                    callback.invoke(origin, true, false);
                } else {
                    pendingGeoOrigin = origin;
                    pendingGeoCallback = callback;
                    requestRuntimePermissions(new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                    });
                }
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams fileChooserParams) {
                if (!permFiles) {
                    callback.onReceiveValue(null);
                    return true;
                }
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                try {
                    Intent intent = fileChooserParams.createIntent();
                    startActivityForResult(intent, REQ_FILE_CHOOSER);
                } catch (Exception e) {
                    Intent fallback = new Intent(Intent.ACTION_GET_CONTENT);
                    fallback.addCategory(Intent.CATEGORY_OPENABLE);
                    fallback.setType("*/*");
                    startActivityForResult(Intent.createChooser(fallback, "Selecionar arquivo"), REQ_FILE_CHOOSER);
                }
                return true;
            }
        });

        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
                if (!permFiles) {
                    openExternalUri(url);
                    return;
                }
                try {
                    DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                    req.setMimeType(mimetype);
                    req.addRequestHeader("User-Agent", userAgent);
                    req.setTitle(URLUtil.guessFileName(url, contentDisposition, mimetype));
                    req.allowScanningByMediaScanner();
                    req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                            URLUtil.guessFileName(url, contentDisposition, mimetype));
                    DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                    if (dm != null) {
                        dm.enqueue(req);
                        Toast.makeText(MainActivity.this, "Download iniciado...", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    openExternalUri(url);
                }
            }
        });
    }

    private void injectMobileViewportLock() {
        String content = disableZoom
                ? "width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"
                : "width=device-width, initial-scale=1.0";
        String js = "(function(){"
                + "var m=document.querySelector('meta[name=\"viewport\"]');"
                + "if(!m){m=document.createElement('meta');m.name='viewport';document.head.appendChild(m);}"
                + "m.content='" + content + "';"
                + "var s=document.getElementById('web2app-mobile-lock');"
                + "if(!s){s=document.createElement('style');s.id='web2app-mobile-lock';"
                + "s.textContent='html,body{touch-action:manipulation;-webkit-text-size-adjust:100%;}';"
                + "document.head.appendChild(s);}"
                + "})();";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            webView.evaluateJavascript(js, null);
        }
    }

    private boolean handleUrlNavigation(String url) {
        if (url == null || url.isEmpty()) return false;
        String lower = url.toLowerCase();

        // Handle Android intent:// URIs
        if (lower.startsWith("intent://")) {
            if (!openExternalApps) return true;
            try {
                Intent intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                if (intent != null) {
                    if (intent.resolveActivity(getPackageManager()) != null) {
                        startActivity(intent);
                        return true;
                    }
                    String fallbackUrl = intent.getStringExtra("browser_fallback_url");
                    if (fallbackUrl != null && !fallbackUrl.isEmpty()) {
                        webView.loadUrl(fallbackUrl);
                        return true;
                    }
                }
            } catch (Exception ignored) {
            }
            return true;
        }

        // Custom app schemes (youtube:, whatsapp:, tel:, mailto:, geo:, pix:, etc.)
        if (!lower.startsWith("http://") && !lower.startsWith("https://")) {
            if (openExternalApps) {
                openExternalUri(url);
            }
            return true;
        }

        // External app HTTPS deep links (YouTube, WhatsApp, Maps, Play Store, Spotify)
        if (openExternalApps) {
            try {
                Uri parsed = Uri.parse(url);
                String host = parsed.getHost() != null ? parsed.getHost().toLowerCase() : "";
                if (!host.equals(homeHost) && isExternalAppDomain(host)) {
                    Intent ext = new Intent(Intent.ACTION_VIEW, parsed);
                    ext.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    if (ext.resolveActivity(getPackageManager()) != null) {
                        startActivity(ext);
                        return true;
                    }
                }
            } catch (Exception ignored) {
            }
        }
        return false;
    }

    private boolean isExternalAppDomain(String host) {
        return host.equals("youtube.com")
                || host.equals("www.youtube.com")
                || host.equals("m.youtube.com")
                || host.equals("youtu.be")
                || host.equals("wa.me")
                || host.equals("api.whatsapp.com")
                || host.equals("play.google.com")
                || host.equals("maps.app.goo.gl")
                || host.equals("maps.google.com")
                || host.equals("open.spotify.com");
    }

    private void openExternalUri(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception ignored) {
        }
    }

    private boolean hasPerm(String permission) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;
        return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestRuntimePermissions(String[] perms) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && perms.length > 0) {
            requestPermissions(perms, REQ_RUNTIME_PERMS);
        }
    }

    private void requestStartupPermissions() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return;
        List<String> needed = new ArrayList<>();
        if (permCamera && !hasPerm(Manifest.permission.CAMERA)) {
            needed.add(Manifest.permission.CAMERA);
        }
        if (permMicrophone && !hasPerm(Manifest.permission.RECORD_AUDIO)) {
            needed.add(Manifest.permission.RECORD_AUDIO);
        }
        if (permLocation && !hasPerm(Manifest.permission.ACCESS_FINE_LOCATION)) {
            needed.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (permFiles) {
            if (Build.VERSION.SDK_INT >= 33) {
                if (!hasPerm("android.permission.READ_MEDIA_IMAGES")) {
                    needed.add("android.permission.READ_MEDIA_IMAGES");
                }
                if (!hasPerm("android.permission.READ_MEDIA_VIDEO")) {
                    needed.add("android.permission.READ_MEDIA_VIDEO");
                }
            } else if (!hasPerm(Manifest.permission.READ_EXTERNAL_STORAGE)) {
                needed.add(Manifest.permission.READ_EXTERNAL_STORAGE);
            }
        }
        if (!needed.isEmpty()) {
            requestPermissions(needed.toArray(new String[0]), REQ_RUNTIME_PERMS);
        }
    }

    private void promptBiometricsThenLoad() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                KeyguardManager km = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
                if (km != null && km.isKeyguardSecure()) {
                    Intent authIntent = km.createConfirmDeviceCredentialIntent(
                            appName,
                            "Confirme sua biometria ou senha do aparelho para abrir"
                    );
                    if (authIntent != null) {
                        startActivityForResult(authIntent, REQ_BIOMETRICS);
                        return;
                    }
                }
            } catch (Exception ignored) {
            }
        }
        loadInitialSite();
    }

    private void loadInitialSite() {
        if (webView != null) {
            webView.loadUrl(websiteUrl);
        }
    }

    private void syncRemoteConfigAsync() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    HttpURLConnection conn = (HttpURLConnection) new URL(remoteConfigEndpoint).openConnection();
                    conn.setConnectTimeout(5000);
                    conn.setReadTimeout(5000);
                    if (conn.getResponseCode() == 200) {
                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                        StringBuilder sb = new StringBuilder();
                        String line;
                        while ((line = br.readLine()) != null) sb.append(line);
                        br.close();
                        final String previousUrl = websiteUrl;
                        JSONObject json = new JSONObject(sb.toString());
                        applyJsonConfig(json, true);
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (headerTitleView != null) headerTitleView.setText(appName);
                                if (splashTitle != null) splashTitle.setText(appName);
                                applyThemeColors();
                                if (!websiteUrl.equals(previousUrl) && webView != null) {
                                    webView.loadUrl(websiteUrl);
                                }
                            }
                        });
                    }
                } catch (Exception ignored) {
                }
            }
        }).start();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_RUNTIME_PERMS) {
            if (pendingWebPermissionRequest != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                List<String> granted = new ArrayList<>();
                for (String res : pendingWebPermissionRequest.getResources()) {
                    if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res) && permCamera && hasPerm(Manifest.permission.CAMERA)) {
                        granted.add(res);
                    } else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res) && permMicrophone && hasPerm(Manifest.permission.RECORD_AUDIO)) {
                        granted.add(res);
                    }
                }
                if (!granted.isEmpty()) {
                    pendingWebPermissionRequest.grant(granted.toArray(new String[0]));
                } else {
                    pendingWebPermissionRequest.deny();
                }
                pendingWebPermissionRequest = null;
            }
            if (pendingGeoCallback != null) {
                boolean geoOk = hasPerm(Manifest.permission.ACCESS_FINE_LOCATION) || hasPerm(Manifest.permission.ACCESS_COARSE_LOCATION);
                pendingGeoCallback.invoke(pendingGeoOrigin, geoOk, false);
                pendingGeoCallback = null;
                pendingGeoOrigin = null;
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_BIOMETRICS) {
            if (resultCode == RESULT_OK) {
                loadInitialSite();
            } else {
                finish();
            }
            return;
        }
        if (requestCode == REQ_FILE_CHOOSER && filePathCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) {
                        results[i] = data.getClipData().getItemAt(i).getUri();
                    }
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
