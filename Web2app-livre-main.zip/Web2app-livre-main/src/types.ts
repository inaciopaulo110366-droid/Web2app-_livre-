import type { Timestamp } from 'firebase/firestore';

export type AppOrientation = 'portrait' | 'landscape' | 'sensor';
export type AppStatus = 'ready' | 'published';
export type ExportFormat = 'apk' | 'aab' | 'source';
export type SplashAnimation = 'none' | 'pulse' | 'zoom' | 'bounce' | 'fade';

export interface AppProject {
  id: string;
  ownerId: string;
  name: string;
  websiteUrl: string;
  packageName: string;
  iconUrl: string;
  themeColor: string;
  splashBgColor: string;
  splashAnimation: SplashAnimation;
  versionName: string;
  versionCode: number;
  autoUpdateEnabled: boolean;
  autoSyncIcon: boolean;
  showNavBar: boolean;
  pullToRefresh: boolean;
  fullscreenMode: boolean;
  lockMobileViewport: boolean;
  disableZoom: boolean;
  openExternalApps: boolean;
  permCamera: boolean;
  permMicrophone: boolean;
  permLocation: boolean;
  permFiles: boolean;
  permBiometrics: boolean;
  orientation: AppOrientation;
  status: AppStatus;
  lastExportFormat?: string;
  lastExportAt?: Timestamp;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface AppRevision {
  id: string;
  appId: string;
  ownerId: string;
  versionName: string;
  versionCode: number;
  changeSummary: string;
  nameSnapshot: string;
  urlSnapshot: string;
  iconSnapshot: string;
  exportFormat: 'config' | 'apk' | 'aab' | 'source';
  createdAt?: Timestamp;
}

export interface CandidateIcon {
  originalUrl: string;
  proxyUrl: string;
  size: number;
  source: string;
}

export interface UrlInspectionResult {
  websiteUrl: string;
  name: string;
  description: string;
  packageName: string;
  themeColor: string;
  isHttps: boolean;
  hasViewportMeta: boolean;
  primaryIconUrl: string;
  candidateIcons: CandidateIcon[];
  partialNotice?: string;
}
