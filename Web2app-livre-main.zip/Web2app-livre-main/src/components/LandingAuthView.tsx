import React, { useState } from 'react';
import {
  ArrowRight,
  Check,
  Download,
  Globe,
  RefreshCw,
  Search,
  Smartphone,
} from 'lucide-react';
import heroMobileStudio from '../assets/images/hero_mobile_studio_1794784475031.jpg';
import type { UrlInspectionResult } from '../types';

interface LandingAuthViewProps {
  onGoogleLogin: () => Promise<void>;
  isSigningIn: boolean;
  authError: string | null;
  onInspectPreviewUrl: (url: string) => Promise<UrlInspectionResult | null>;
}

export function LandingAuthView({
  onGoogleLogin,
  isSigningIn,
  authError,
  onInspectPreviewUrl,
}: LandingAuthViewProps) {
  const [testUrl, setTestUrl] = useState('https://mercadolivre.com.br');
  const [isInspecting, setIsInspecting] = useState(false);
  const [inspection, setInspection] = useState<UrlInspectionResult | null>(null);
  const [inspectError, setInspectError] = useState<string | null>(null);
  const [heroImgFailed, setHeroImgFailed] = useState(false);

  async function handleQuickTest(e: React.FormEvent) {
    e.preventDefault();
    if (!testUrl.trim()) return;
    setIsInspecting(true);
    setInspectError(null);
    try {
      const result = await onInspectPreviewUrl(testUrl);
      if (result) {
        setInspection(result);
      } else {
        setInspectError('Não foi possível ler os dados deste endereço. Verifique o link informado.');
      }
    } catch {
      setInspectError('Erro ao inspecionar o site. Tente outro endereço.');
    } finally {
      setIsInspecting(false);
    }
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col">
      {/* Top Bar: strict 3-zone contract */}
      <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-14 sm:h-16 flex items-center justify-between gap-8">
          <a
            href="#top"
            className="font-display text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0"
          >
            Web2App Livre
          </a>

          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600">
            <a
              href="#como-funciona"
              className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
            >
              Como funciona
            </a>
            <a
              href="#auto-update"
              className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
            >
              Atualização Automática
            </a>
            <a
              href="#exportacao"
              className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
            >
              APK e AAB
            </a>
            <a
              href="#testar"
              className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
            >
              Testar Link
            </a>
          </nav>

          <button
            type="button"
            onClick={onGoogleLogin}
            disabled={isSigningIn}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700 disabled:opacity-60 transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-2"
          >
            <span>{isSigningIn ? 'Conectando...' : 'Entrar com Google'}</span>
          </button>
        </div>
      </header>

      <main id="top" className="flex-1">
        {/* Hero Split */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-14 lg:py-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
            <div className="lg:col-span-6 flex flex-col justify-center">
              <p className="text-xs font-medium text-blue-600 mb-3">
                100% Gratuito · Login Gmail · Exportação APK e AAB
              </p>

              <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-slate-900 leading-[1.12] text-balance mb-4">
                Converta qualquer site em App Android grátis
              </h1>

              <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-xl mb-7">
                Entre com sua conta Google, cole o link do seu site e gere um aplicativo nativo
                com busca automática de ícone, gerenciamento de atualizações em tempo real e
                exportação direta em APK e AAB sem custo.
              </p>

              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 mb-4">
                <button
                  type="button"
                  onClick={onGoogleLogin}
                  disabled={isSigningIn}
                  className="min-h-[48px] px-6 py-3 rounded-xl bg-slate-900 text-white text-sm sm:text-base font-semibold hover:bg-slate-800 disabled:opacity-60 transition-colors flex items-center justify-center gap-3 cursor-pointer"
                >
                  <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24" aria-hidden="true">
                    <path
                      fill="#EA4335"
                      d="M12 5c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 1.19 14.97 0 12 0 7.31 0 3.26 2.69 1.29 6.61l3.66 2.84C5.81 6.86 8.65 5 12 5z"
                    />
                    <path
                      fill="#4285F4"
                      d="M23.49 12.27c0-.79-.07-1.54-.19-2.27H12v4.51h6.47c-.29 1.48-1.14 2.73-2.4 3.58l3.71 2.88c2.17-2 3.71-4.95 3.71-8.7z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M4.95 14.55A7.19 7.19 0 0 1 4.56 12c0-.89.15-1.75.39-2.55L1.29 6.61A11.98 11.98 0 0 0 0 12c0 1.94.46 3.77 1.29 5.39l3.66-2.84z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.71-2.88c-1.08.72-2.45 1.16-4.22 1.16-3.35 0-6.19-1.86-7.05-4.45l-3.66 2.84C3.26 21.31 7.31 24 12 24z"
                    />
                  </svg>
                  <span>
                    {isSigningIn ? 'Abrindo login Google...' : 'Continuar grátis com Google / Gmail'}
                  </span>
                  <ArrowRight className="w-4 h-4 shrink-0" />
                </button>
              </div>

              {authError && (
                <p className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-xl px-4 py-2.5 mb-4">
                  {authError}
                </p>
              )}

              <div className="flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-slate-500 pt-2">
                <span className="inline-flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  Sem mensalidade ou marca d&apos;água
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  Busca automática de ícone e nome
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  Exportação APK e AAB ilimitada
                </span>
              </div>
            </div>

            <div className="lg:col-span-6 flex">
              <div className="w-full rounded-3xl overflow-hidden border border-slate-200 bg-white flex flex-col">
                {!heroImgFailed ? (
                  <img
                    src={heroMobileStudio}
                    alt="Smartphone Android exibindo aplicativos convertidos com Web2App Livre"
                    referrerPolicy="no-referrer"
                    onError={() => setHeroImgFailed(true)}
                    className="w-full h-64 sm:h-80 lg:h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-64 sm:h-80 lg:h-full bg-slate-100 flex flex-col items-center justify-center p-8 text-center">
                    <Smartphone className="w-12 h-12 text-blue-600 mb-3" />
                    <p className="font-display font-semibold text-slate-900">
                      Estúdio Android Web2App Livre
                    </p>
                    <p className="text-sm text-slate-500 mt-1">
                      Preview mobile e geração direta em APK e AAB
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>

        {/* Live URL & Auto Icon Tester */}
        <section id="testar" className="max-w-7xl mx-auto px-4 sm:px-6 pb-12">
          <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-7">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-5">
              <div>
                <h2 className="font-display text-lg sm:text-xl font-bold text-slate-900">
                  Teste a busca automática de nome e ícone agora
                </h2>
                <p className="text-sm text-slate-600 mt-0.5">
                  Digite qualquer site existente para extrair o título, cor e ícone automaticamente.
                </p>
              </div>
            </div>

            <form onSubmit={handleQuickTest} className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Globe className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={testUrl}
                  onChange={(e) => setTestUrl(e.target.value)}
                  placeholder="https://seusite.com.br"
                  aria-label="Endereço do site para testar"
                  className="w-full min-h-[48px] pl-10 pr-4 rounded-xl border border-slate-300 bg-white text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-blue-600"
                />
              </div>
              <button
                type="submit"
                disabled={isInspecting}
                className="min-h-[48px] px-5 py-2.5 rounded-xl bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700 disabled:opacity-60 transition-colors flex items-center justify-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Search className="w-4 h-4" />
                <span>{isInspecting ? 'Analisando site...' : 'Buscar Ícone e Dados'}</span>
              </button>
            </form>

            {inspectError && (
              <p className="text-sm text-red-600 mt-3">{inspectError}</p>
            )}

            {inspection && (
              <div className="mt-5 pt-5 border-t border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="flex items-center gap-4 min-w-0">
                  <div className="w-14 h-14 rounded-2xl border border-slate-200 bg-slate-100 flex items-center justify-center overflow-hidden shrink-0">
                    {inspection.primaryIconUrl || inspection.candidateIcons[0]?.proxyUrl ? (
                      <img
                        src={inspection.primaryIconUrl || inspection.candidateIcons[0]?.proxyUrl}
                        alt={`Ícone de ${inspection.name}`}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-contain p-1.5"
                      />
                    ) : (
                      <Smartphone className="w-6 h-6 text-slate-400" />
                    )}
                  </div>
                  <div className="min-w-0">
                    <p className="font-display font-bold text-slate-900 truncate">
                      {inspection.name}
                    </p>
                    <p className="text-xs text-slate-500 font-mono truncate">
                      {inspection.packageName} · {inspection.websiteUrl}
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={onGoogleLogin}
                  className="min-h-[44px] px-4 py-2 rounded-xl bg-slate-900 text-white text-sm font-semibold hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  Converter este site grátis
                </button>
              </div>
            )}
          </div>
        </section>

        {/* 3-Column Feature Architecture */}
        <section
          id="como-funciona"
          className="max-w-7xl mx-auto px-4 sm:px-6 pb-16 grid grid-cols-1 md:grid-cols-3 gap-6"
        >
          <div id="auto-update" className="bg-white border border-slate-200 rounded-2xl p-6">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mb-4">
              <Search className="w-5 h-5" />
            </div>
            <h3 className="font-display text-base font-bold text-slate-900 mb-2">
              01. Busca automática de ícone e metadados
            </h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Informe apenas o link do site. O sistema identifica nome, cor de tema, manifesto PWA
              e o ícone de maior resolução automaticamente, com opção de upload personalizado.
            </p>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-6">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mb-4">
              <RefreshCw className="w-5 h-5" />
            </div>
            <h3 className="font-display text-base font-bold text-slate-900 mb-2">
              02. Atualizações automáticas no painel
            </h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Altere nome, link de destino ou ícone no painel a qualquer momento. A sincronização
              remota atualiza a configuração do aplicativo sem que você precise começar do zero.
            </p>
          </div>

          <div id="exportacao" className="bg-white border border-slate-200 rounded-2xl p-6">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mb-4">
              <Download className="w-5 h-5" />
            </div>
            <h3 className="font-display text-base font-bold text-slate-900 mb-2">
              03. Exportação direta em APK e AAB
            </h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Baixe gratuitamente o pacote APK para instalação e testes no celular, o arquivo AAB
              para publicação na Google Play ou o projeto Android Studio completo em ZIP.
            </p>
          </div>
        </section>
      </main>

      <footer className="border-t border-slate-200 bg-white py-6 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <span>Web2App Livre · Conversor gratuito de sites para aplicativos Android</span>
          <span>Login seguro via Google · Sincronização na nuvem</span>
        </div>
      </footer>
    </div>
  );
}
