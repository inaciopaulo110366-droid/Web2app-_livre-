import React, { useState } from 'react';
import {
  ArrowLeft,
  Camera,
  ExternalLink,
  Folder,
  Globe,
  Home,
  MessageSquare,
  RefreshCw,
  RotateCcw,
  Smartphone,
  Wifi,
} from 'lucide-react';
import type { AppProject } from '../types';

interface DevicePreviewProps {
  app: AppProject;
  fallbackIcon: string;
}

type PreviewMode = 'webview' | 'splash' | 'homescreen';

function getSplashAnimClass(anim: AppProject['splashAnimation']): string {
  switch (anim) {
    case 'pulse':
      return 'animate-splash-pulse';
    case 'bounce':
      return 'animate-splash-bounce';
    case 'fade':
      return 'animate-splash-fade';
    case 'zoom':
      return 'animate-splash-zoom';
    default:
      return '';
  }
}

function isDarkHex(hex: string): boolean {
  const clean = (hex || '#FFFFFF').replace('#', '');
  if (clean.length !== 6) return false;
  const r = parseInt(clean.slice(0, 2), 16);
  const g = parseInt(clean.slice(2, 4), 16);
  const b = parseInt(clean.slice(4, 6), 16);
  return (0.299 * r + 0.587 * g + 0.114 * b) / 255 < 0.5;
}

export function DevicePreview({ app, fallbackIcon }: DevicePreviewProps) {
  const [mode, setMode] = useState<PreviewMode>('webview');
  const [iframeKey, setIframeKey] = useState(0);
  const [iframeLoaded, setIframeLoaded] = useState(false);
  const [splashReplayKey, setSplashReplayKey] = useState(0);

  const effectiveIcon = app.iconUrl || fallbackIcon;
  const displayUrl = app.websiteUrl.startsWith('http')
    ? app.websiteUrl
    : `https://${app.websiteUrl}`;

  let hostname = 'site.com';
  try {
    hostname = new URL(displayUrl).hostname.replace(/^www\./, '');
  } catch {
    hostname = app.websiteUrl;
  }

  const splashDark = isDarkHex(app.splashBgColor);

  return (
    <div className="flex flex-col items-center">
      {/* Segmented preview mode tabs */}
      <div className="w-full max-w-[320px] grid grid-cols-3 gap-1 p-1 bg-slate-200/80 rounded-xl mb-4">
        <button
          type="button"
          onClick={() => setMode('webview')}
          className={`min-h-[38px] px-2 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
            mode === 'webview'
              ? 'bg-white text-slate-900 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          App Aberto
        </button>
        <button
          type="button"
          onClick={() => {
            setMode('splash');
            setSplashReplayKey((k) => k + 1);
          }}
          className={`min-h-[38px] px-2 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
            mode === 'splash'
              ? 'bg-white text-slate-900 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Splash
        </button>
        <button
          type="button"
          onClick={() => setMode('homescreen')}
          className={`min-h-[38px] px-2 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
            mode === 'homescreen'
              ? 'bg-white text-slate-900 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Tela Inicial
        </button>
      </div>

      {/* Android Device Bezel */}
      <div className="w-[300px] sm:w-[316px] h-[590px] rounded-[42px] bg-slate-900 p-2.5 shadow-xl border border-slate-800 flex flex-col">
        <div className="w-full h-full rounded-[34px] bg-white overflow-hidden flex flex-col relative">
          {/* Status bar */}
          {!app.fullscreenMode && (
            <div
              className="h-7 px-5 flex items-center justify-between text-[11px] font-medium text-white shrink-0 transition-colors"
              style={{
                backgroundColor:
                  mode === 'homescreen' ? '#0F172A' : app.themeColor || '#2563EB',
              }}
            >
              <span className="tabular-nums">15:12</span>
              <div className="w-3 h-3 rounded-full bg-black/40" aria-hidden="true" />
              <div className="flex items-center gap-1.5">
                <Wifi className="w-3 h-3" />
                <span className="tabular-nums">100%</span>
              </div>
            </div>
          )}

          {/* Mode 1: Active WebView App */}
          {mode === 'webview' && (
            <div className="flex-1 flex flex-col bg-white overflow-hidden">
              {app.showNavBar && (
                <div
                  className="h-12 px-3 flex items-center justify-between text-white shrink-0 transition-colors"
                  style={{ backgroundColor: app.themeColor || '#2563EB' }}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    {effectiveIcon ? (
                      <img
                        src={effectiveIcon}
                        alt={app.name}
                        referrerPolicy="no-referrer"
                        className="w-6 h-6 rounded-md bg-white object-contain p-0.5 shrink-0"
                      />
                    ) : (
                      <Smartphone className="w-5 h-5 shrink-0" />
                    )}
                    <span className="text-sm font-semibold truncate">{app.name || 'Meu App'}</span>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    {app.pullToRefresh && (
                      <button
                        type="button"
                        onClick={() => {
                          setIframeLoaded(false);
                          setIframeKey((k) => k + 1);
                        }}
                        title="Recarregar site no preview"
                        className="w-8 h-8 rounded-lg hover:bg-white/15 flex items-center justify-center cursor-pointer"
                      >
                        <RefreshCw className="w-4 h-4" />
                      </button>
                    )}
                    <a
                      href={displayUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      title="Abrir site em nova aba"
                      className="w-8 h-8 rounded-lg hover:bg-white/15 flex items-center justify-center"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  </div>
                </div>
              )}

              <div className="flex-1 relative bg-slate-50 overflow-hidden">
                <iframe
                  key={`${displayUrl}-${iframeKey}`}
                  src={displayUrl}
                  title={`Preview de ${app.name}`}
                  onLoad={() => setIframeLoaded(true)}
                  className="w-full h-full border-0 bg-white"
                  sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
                />
                {!iframeLoaded && (
                  <div className="absolute inset-0 bg-slate-50 flex flex-col items-center justify-center p-6 text-center pointer-events-none">
                    <div className="w-16 h-16 rounded-2xl border border-slate-200 bg-white flex items-center justify-center overflow-hidden mb-3 shadow-sm">
                      {effectiveIcon ? (
                        <img
                          src={effectiveIcon}
                          alt={app.name}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-contain p-2"
                        />
                      ) : (
                        <Globe className="w-7 h-7 text-blue-600" />
                      )}
                    </div>
                    <p className="font-display font-semibold text-sm text-slate-900">
                      {app.name || 'Meu App'}
                    </p>
                    <p className="text-xs text-slate-500 font-mono mt-1 break-all">{hostname}</p>
                    <p className="text-[11px] text-slate-400 mt-3 leading-relaxed">
                      Modo Mobile Nativo ativo ({app.disableZoom ? 'sem zoom' : 'com zoom'} ·{' '}
                      {app.openExternalApps ? 'abre YouTube/apps externos' : 'navegação interna'}).
                    </p>
                  </div>
                )}
              </div>

              {/* Android bottom gesture bar */}
              <div className="h-7 bg-slate-950 text-slate-400 flex items-center justify-around px-8 shrink-0">
                <ArrowLeft className="w-3.5 h-3.5" />
                <div className="w-12 h-1 rounded-full bg-slate-500" />
                <Home className="w-3.5 h-3.5" />
              </div>
            </div>
          )}

          {/* Mode 2: Animated Splash Screen */}
          {mode === 'splash' && (
            <div
              className="flex-1 flex flex-col items-center justify-center p-6 text-center transition-colors relative"
              style={{ backgroundColor: app.splashBgColor || '#FFFFFF' }}
            >
              <div
                key={`${app.splashAnimation}-${splashReplayKey}`}
                className={`w-24 h-24 rounded-3xl shadow-md bg-white border border-slate-200/70 flex items-center justify-center overflow-hidden mb-5 ${getSplashAnimClass(
                  app.splashAnimation
                )}`}
              >
                {effectiveIcon ? (
                  <img
                    src={effectiveIcon}
                    alt={app.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-contain p-2"
                  />
                ) : (
                  <Smartphone className="w-10 h-10 text-blue-600" />
                )}
              </div>
              <p
                className={`font-display text-lg font-bold ${
                  splashDark ? 'text-white' : 'text-slate-900'
                }`}
              >
                {app.name || 'Meu App'}
              </p>
              <p
                className={`text-xs mt-1 font-mono ${
                  splashDark ? 'text-slate-300' : 'text-slate-500'
                }`}
              >
                {hostname}
              </p>
              <div className="mt-8 w-24 h-1 rounded-full bg-slate-200/70 overflow-hidden">
                <div
                  className="h-full w-1/2 rounded-full"
                  style={{ backgroundColor: app.themeColor || '#2563EB' }}
                />
              </div>

              <button
                type="button"
                onClick={() => setSplashReplayKey((k) => k + 1)}
                className="mt-8 min-h-[36px] px-3 py-1.5 rounded-lg bg-slate-900/80 text-white text-xs font-medium inline-flex items-center gap-1.5 hover:bg-slate-900 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Repetir animação</span>
              </button>
            </div>
          )}

          {/* Mode 3: Android Home Screen */}
          {mode === 'homescreen' && (
            <div className="flex-1 bg-slate-900 text-white p-5 flex flex-col justify-between">
              <div>
                <div className="py-4 text-center">
                  <p className="text-3xl font-light tabular-nums tracking-tight">15:12</p>
                  <p className="text-xs text-slate-400 mt-0.5">Dom, 15 de nov</p>
                </div>

                <div className="grid grid-cols-4 gap-3 mt-6">
                  {/* Converted App Icon */}
                  <button
                    type="button"
                    onClick={() => setMode('webview')}
                    className="flex flex-col items-center gap-1.5 group cursor-pointer"
                  >
                    <div className="w-12 h-12 rounded-2xl bg-white shadow-md flex items-center justify-center overflow-hidden group-hover:scale-105 transition-transform">
                      {effectiveIcon ? (
                        <img
                          src={effectiveIcon}
                          alt={app.name}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-contain p-1"
                        />
                      ) : (
                        <Smartphone className="w-6 h-6 text-blue-600" />
                      )}
                    </div>
                    <span className="text-[10px] text-white font-medium text-center leading-tight line-clamp-1 w-full">
                      {app.name || 'Meu App'}
                    </span>
                  </button>

                  {/* System sibling icons */}
                  <div className="flex flex-col items-center gap-1.5 opacity-75">
                    <div className="w-12 h-12 rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center">
                      <Camera className="w-5 h-5 text-slate-300" />
                    </div>
                    <span className="text-[10px] text-slate-300 text-center">Câmera</span>
                  </div>
                  <div className="flex flex-col items-center gap-1.5 opacity-75">
                    <div className="w-12 h-12 rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center">
                      <MessageSquare className="w-5 h-5 text-slate-300" />
                    </div>
                    <span className="text-[10px] text-slate-300 text-center">Mensagens</span>
                  </div>
                  <div className="flex flex-col items-center gap-1.5 opacity-75">
                    <div className="w-12 h-12 rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center">
                      <Folder className="w-5 h-5 text-slate-300" />
                    </div>
                    <span className="text-[10px] text-slate-300 text-center">Arquivos</span>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <div className="bg-slate-800/90 rounded-full px-4 py-2.5 flex items-center gap-2 text-xs text-slate-400">
                  <Globe className="w-3.5 h-3.5" />
                  <span>Pesquisar no Android</span>
                </div>
                <div className="flex justify-center pt-1">
                  <div className="w-20 h-1 rounded-full bg-slate-600" />
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      <p className="text-xs text-slate-500 mt-3 text-center">
        Pacote: <span className="font-mono text-slate-700">{app.packageName}</span> · v
        <span className="tabular-nums">{app.versionName}</span>
      </p>
    </div>
  );
}
