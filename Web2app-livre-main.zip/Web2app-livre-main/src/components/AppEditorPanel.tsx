import React, { useRef, useState } from 'react';
import {
  Camera,
  Check,
  Code2,
  Copy,
  Download,
  ExternalLink,
  FileArchive,
  Fingerprint,
  FolderOpen,
  Globe,
  History,
  ImagePlus,
  Loader2,
  MapPin,
  Mic,
  Package,
  Palette,
  RefreshCw,
  Save,
  Search,
  Settings2,
  Smartphone,
  Trash2,
} from 'lucide-react';
import type {
  AppOrientation,
  AppProject,
  AppRevision,
  CandidateIcon,
  ExportFormat,
  SplashAnimation,
} from '../types';
import { fileToPngDataUrl, imageSourceToPngDataUrl, sanitizePackageName } from '../utils/iconHelper';

export type EditorTab = 'geral' | 'aparencia' | 'exportar' | 'historico';

interface AppEditorPanelProps {
  draft: AppProject;
  activeTab: EditorTab;
  onTabChange: (tab: EditorTab) => void;
  onChange: (patch: Partial<AppProject>) => void;
  onSaveNow: () => Promise<void>;
  onInspectWebsite: (url: string) => Promise<CandidateIcon[]>;
  onExport: (format: ExportFormat) => Promise<void>;
  onDeleteApp: () => Promise<void>;
  revisions: AppRevision[];
  candidateIcons: CandidateIcon[];
  fallbackIcon: string;
  isSaving: boolean;
  isInspecting: boolean;
  exportingFormat: ExportFormat | null;
  saveFeedback: string | null;
  inspectMessage: string | null;
  hasUnsavedChanges: boolean;
}

export function AppEditorPanel({
  draft,
  activeTab,
  onTabChange,
  onChange,
  onSaveNow,
  onInspectWebsite,
  onExport,
  onDeleteApp,
  revisions,
  candidateIcons,
  fallbackIcon,
  isSaving,
  isInspecting,
  exportingFormat,
  saveFeedback,
  inspectMessage,
  hasUnsavedChanges,
}: AppEditorPanelProps) {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [copiedEndpoint, setCopiedEndpoint] = useState(false);
  const [liveEndpointJson, setLiveEndpointJson] = useState<string | null>(null);
  const [isTestingEndpoint, setIsTestingEndpoint] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [iconProcessError, setIconProcessError] = useState<string | null>(null);

  const remoteEndpoint = `${window.location.origin}/api/app-config/${draft.id}`;
  const effectiveIcon = draft.iconUrl || fallbackIcon;

  async function handleInspectSubmit(e: React.FormEvent) {
    e.preventDefault();
    await onInspectWebsite(draft.websiteUrl);
  }

  async function handleSelectCandidateIcon(proxyUrl: string) {
    setIconProcessError(null);
    try {
      const pngDataUrl = await imageSourceToPngDataUrl(proxyUrl, 192);
      if (pngDataUrl.length <= 145000) {
        onChange({ iconUrl: pngDataUrl });
      } else {
        setIconProcessError('Este ícone excedeu o tamanho máximo permitido.');
      }
    } catch {
      setIconProcessError('Não foi possível converter este ícone. Tente outro ou envie um arquivo.');
    }
  }

  async function handleFileUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setIconProcessError(null);
    try {
      const pngDataUrl = await fileToPngDataUrl(file);
      if (pngDataUrl.length <= 145000) {
        onChange({ iconUrl: pngDataUrl });
      } else {
        setIconProcessError('A imagem é muito complexa. Use um ícone mais simples ou menor.');
      }
    } catch {
      setIconProcessError('Arquivo de imagem inválido. Selecione PNG, JPG ou SVG.');
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  }

  async function handleCopyEndpoint() {
    try {
      await navigator.clipboard.writeText(remoteEndpoint);
      setCopiedEndpoint(true);
      setTimeout(() => setCopiedEndpoint(false), 2000);
    } catch {
      // Ignore clipboard error
    }
  }

  async function handleTestLiveEndpoint() {
    setIsTestingEndpoint(true);
    try {
      const res = await fetch(remoteEndpoint);
      const data = await res.json();
      setLiveEndpointJson(JSON.stringify(data, null, 2));
    } catch {
      setLiveEndpointJson('{"erro": "Falha ao consultar endpoint remoto"}');
    } finally {
      setIsTestingEndpoint(false);
    }
  }

  return (
    <div className="space-y-5">
      {/* Auto-Inspect Bar */}
      <form
        onSubmit={handleInspectSubmit}
        className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5"
      >
        <div className="flex items-center justify-between gap-3 mb-3">
          <div>
            <h2 className="font-display text-sm sm:text-base font-bold text-slate-900">
              Extrair nome e ícone automaticamente do site
            </h2>
            <p className="text-xs text-slate-500">
              Cole ou atualize o link para buscar automaticamente o nome, cor e ícone oficial.
            </p>
          </div>
          {saveFeedback && (
            <span className="text-xs font-medium text-emerald-700 inline-flex items-center gap-1 whitespace-nowrap shrink-0">
              <Check className="w-3.5 h-3.5" />
              {saveFeedback}
            </span>
          )}
        </div>

        <div className="flex flex-col sm:flex-row gap-2.5">
          <div className="relative flex-1">
            <Globe className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={draft.websiteUrl}
              onChange={(e) => onChange({ websiteUrl: e.target.value })}
              placeholder="https://seusite.com.br"
              aria-label="Link do site"
              className="w-full min-h-[44px] pl-10 pr-3 rounded-xl border border-slate-300 bg-white text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
          </div>
          <button
            type="submit"
            disabled={isInspecting}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-slate-900 text-white text-xs sm:text-sm font-semibold hover:bg-slate-800 disabled:opacity-60 transition-colors inline-flex items-center justify-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
          >
            {isInspecting ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Search className="w-4 h-4" />
            )}
            <span>{isInspecting ? 'Buscando...' : 'Buscar Ícone e Dados'}</span>
          </button>
        </div>

        {inspectMessage && <p className="text-xs text-blue-700 mt-2.5">{inspectMessage}</p>}
      </form>

      {/* Workspace Sub-Navigation Tabs */}
      <div className="bg-slate-200/70 p-1 rounded-xl grid grid-cols-4 gap-1">
        <button
          type="button"
          onClick={() => onTabChange('geral')}
          className={`min-h-[44px] px-2 py-2 rounded-lg text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeTab === 'geral'
              ? 'bg-white text-slate-900 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Settings2 className="w-4 h-4 shrink-0" />
          <span className="truncate">Geral</span>
        </button>

        <button
          type="button"
          onClick={() => onTabChange('aparencia')}
          className={`min-h-[44px] px-2 py-2 rounded-lg text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeTab === 'aparencia'
              ? 'bg-white text-slate-900 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Palette className="w-4 h-4 shrink-0" />
          <span className="truncate">Visual e Permissões</span>
        </button>

        <button
          type="button"
          onClick={() => onTabChange('exportar')}
          className={`min-h-[44px] px-2 py-2 rounded-lg text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeTab === 'exportar'
              ? 'bg-white text-slate-900 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Download className="w-4 h-4 shrink-0" />
          <span className="truncate">APK e AAB</span>
        </button>

        <button
          type="button"
          onClick={() => onTabChange('historico')}
          className={`min-h-[44px] px-2 py-2 rounded-lg text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeTab === 'historico'
              ? 'bg-white text-slate-900 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <History className="w-4 h-4 shrink-0" />
          <span className="truncate">Histórico</span>
        </button>
      </div>

      {/* TAB 1: GERAL & AUTO-UPDATE */}
      {activeTab === 'geral' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label
                htmlFor="app-name-input"
                className="block text-xs font-semibold text-slate-700 mb-1.5"
              >
                Nome do Aplicativo
              </label>
              <input
                id="app-name-input"
                type="text"
                maxLength={60}
                value={draft.name}
                onChange={(e) => onChange({ name: e.target.value })}
                placeholder="Minha Loja"
                className="w-full min-h-[44px] px-3.5 rounded-xl border border-slate-300 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div>
              <label
                htmlFor="app-package-input"
                className="block text-xs font-semibold text-slate-700 mb-1.5"
              >
                ID do Pacote Android (Package Name)
              </label>
              <input
                id="app-package-input"
                type="text"
                maxLength={120}
                value={draft.packageName}
                onChange={(e) => onChange({ packageName: sanitizePackageName(e.target.value) })}
                placeholder="com.web2app.meuapp"
                className="w-full min-h-[44px] px-3.5 rounded-xl border border-slate-300 text-sm font-mono text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label
                htmlFor="app-version-name"
                className="block text-xs font-semibold text-slate-700 mb-1.5"
              >
                Versão (Version Name)
              </label>
              <input
                id="app-version-name"
                type="text"
                maxLength={20}
                value={draft.versionName}
                onChange={(e) => onChange({ versionName: e.target.value })}
                className="w-full min-h-[44px] px-3.5 rounded-xl border border-slate-300 text-sm font-mono tabular-nums text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>
            <div>
              <label
                htmlFor="app-version-code"
                className="block text-xs font-semibold text-slate-700 mb-1.5"
              >
                Código da Build (Version Code)
              </label>
              <input
                id="app-version-code"
                type="number"
                min={1}
                max={999999}
                value={draft.versionCode}
                onChange={(e) =>
                  onChange({
                    versionCode: Math.max(1, parseInt(e.target.value || '1', 10) || 1),
                  })
                }
                className="w-full min-h-[44px] px-3.5 rounded-xl border border-slate-300 text-sm font-mono tabular-nums text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>
          </div>

          <hr className="border-slate-200" />

          {/* Automatic Update Management */}
          <div className="space-y-3">
            <h3 className="font-display text-sm font-bold text-slate-900">
              Gerenciamento Automático de Atualizações
            </h3>

            <label className="flex items-start justify-between gap-4 p-3.5 rounded-xl border border-slate-200 hover:bg-slate-50 transition-colors cursor-pointer">
              <div>
                <p className="text-sm font-semibold text-slate-900">
                  Sincronização automática (Nome, Link e Ícone)
                </p>
                <p className="text-xs text-slate-500 mt-0.5">
                  Salva e publica alterações automaticamente no endpoint remoto do aplicativo assim
                  que você edita qualquer campo.
                </p>
              </div>
              <input
                type="checkbox"
                checked={draft.autoUpdateEnabled}
                onChange={(e) => onChange({ autoUpdateEnabled: e.target.checked })}
                className="w-5 h-5 mt-0.5 accent-blue-600 rounded shrink-0 cursor-pointer"
              />
            </label>

            <label className="flex items-start justify-between gap-4 p-3.5 rounded-xl border border-slate-200 hover:bg-slate-50 transition-colors cursor-pointer">
              <div>
                <p className="text-sm font-semibold text-slate-900">
                  Buscar ícone automaticamente ao trocar o link
                </p>
                <p className="text-xs text-slate-500 mt-0.5">
                  Atualiza o ícone do app automaticamente sempre que um novo domínio for
                  inspecionado.
                </p>
              </div>
              <input
                type="checkbox"
                checked={draft.autoSyncIcon}
                onChange={(e) => onChange({ autoSyncIcon: e.target.checked })}
                className="w-5 h-5 mt-0.5 accent-blue-600 rounded shrink-0 cursor-pointer"
              />
            </label>
          </div>

          {/* Live Remote Config Endpoint Box */}
          <div className="rounded-xl bg-slate-50 border border-slate-200 p-4 space-y-2.5">
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-semibold text-slate-700">
                Endpoint de Atualização Remota (JSON ao vivo)
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleCopyEndpoint}
                  className="min-h-[34px] px-2.5 py-1 rounded-lg border border-slate-300 bg-white text-xs font-medium text-slate-700 hover:bg-slate-100 inline-flex items-center gap-1 cursor-pointer"
                >
                  {copiedEndpoint ? (
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                  <span>{copiedEndpoint ? 'Copiado' : 'Copiar'}</span>
                </button>
                <button
                  type="button"
                  onClick={handleTestLiveEndpoint}
                  disabled={isTestingEndpoint}
                  className="min-h-[34px] px-2.5 py-1 rounded-lg bg-blue-600 text-white text-xs font-medium hover:bg-blue-700 inline-flex items-center gap-1 cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isTestingEndpoint ? 'animate-spin' : ''}`} />
                  <span>Testar JSON</span>
                </button>
              </div>
            </div>
            <p className="text-xs font-mono text-slate-600 break-all">{remoteEndpoint}</p>
            {liveEndpointJson && (
              <pre className="text-[11px] font-mono bg-slate-900 text-slate-100 rounded-lg p-3 overflow-x-auto max-h-44">
                {liveEndpointJson}
              </pre>
            )}
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
            {!confirmDelete ? (
              <button
                type="button"
                onClick={() => setConfirmDelete(true)}
                className="min-h-[44px] px-3.5 py-2 rounded-xl text-xs font-semibold text-red-600 hover:bg-red-50 transition-colors inline-flex items-center gap-1.5 cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
                <span>Excluir App</span>
              </button>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onDeleteApp}
                  className="min-h-[44px] px-3.5 py-2 rounded-xl bg-red-600 text-white text-xs font-semibold hover:bg-red-700 cursor-pointer"
                >
                  Confirmar Exclusão
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmDelete(false)}
                  className="min-h-[44px] px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  Cancelar
                </button>
              </div>
            )}

            <button
              type="button"
              onClick={onSaveNow}
              disabled={isSaving}
              className="min-h-[44px] px-5 py-2.5 rounded-xl bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700 disabled:opacity-60 transition-colors inline-flex items-center gap-2 cursor-pointer"
            >
              {isSaving ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Save className="w-4 h-4" />
              )}
              <span>
                {isSaving
                  ? 'Salvando...'
                  : hasUnsavedChanges
                    ? 'Salvar e Sincronizar Agora'
                    : 'Sincronizar Atualização'}
              </span>
            </button>
          </div>
        </div>
      )}

      {/* TAB 2: ÍCONE, VISUAL, MODO MOBILE & PERMISSÕES NATIVAS */}
      {activeTab === 'aparencia' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-6">
          {/* App Icon */}
          <div>
            <h3 className="font-display text-sm font-bold text-slate-900 mb-3">
              Ícone do Aplicativo
            </h3>
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
              <div className="w-20 h-20 rounded-2xl border border-slate-200 bg-slate-50 flex items-center justify-center overflow-hidden shrink-0">
                {effectiveIcon ? (
                  <img
                    src={effectiveIcon}
                    alt={draft.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-contain p-1.5"
                  />
                ) : (
                  <Smartphone className="w-8 h-8 text-slate-400" />
                )}
              </div>

              <div className="flex flex-wrap gap-2.5">
                <button
                  type="button"
                  onClick={() => onInspectWebsite(draft.websiteUrl)}
                  disabled={isInspecting}
                  className="min-h-[44px] px-4 py-2 rounded-xl bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800 disabled:opacity-60 transition-colors inline-flex items-center gap-2 cursor-pointer"
                >
                  <RefreshCw className={`w-4 h-4 ${isInspecting ? 'animate-spin' : ''}`} />
                  <span>Buscar Ícone do Site</span>
                </button>

                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="min-h-[44px] px-4 py-2 rounded-xl border border-slate-300 bg-white text-slate-800 text-xs font-semibold hover:bg-slate-50 transition-colors inline-flex items-center gap-2 cursor-pointer"
                >
                  <ImagePlus className="w-4 h-4" />
                  <span>Enviar Imagem</span>
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp,image/svg+xml"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </div>
            </div>

            {iconProcessError && <p className="text-xs text-red-600 mt-2">{iconProcessError}</p>}

            {candidateIcons.length > 0 && (
              <div className="mt-4">
                <p className="text-xs font-medium text-slate-600 mb-2">
                  Ícones encontrados automaticamente no site (toque para usar):
                </p>
                <div className="flex flex-wrap gap-2.5">
                  {candidateIcons.map((cand) => (
                    <button
                      key={cand.originalUrl}
                      type="button"
                      onClick={() => handleSelectCandidateIcon(cand.proxyUrl)}
                      title={`${cand.source} (${cand.size}px)`}
                      className="w-12 h-12 rounded-xl border border-slate-200 bg-slate-50 hover:border-blue-600 hover:bg-blue-50/40 p-1.5 transition-colors flex items-center justify-center cursor-pointer"
                    >
                      <img
                        src={cand.proxyUrl}
                        alt={`Opção ${cand.source}`}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-contain"
                      />
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          <hr className="border-slate-200" />

          {/* Colors & Splash Animation */}
          <div className="space-y-4">
            <h3 className="font-display text-sm font-bold text-slate-900">
              Cores e Animação de Abertura (Splash)
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label
                  htmlFor="theme-color-input"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Cor Principal e Barra de Status
                </label>
                <div className="flex items-center gap-2.5">
                  <input
                    id="theme-color-input"
                    type="color"
                    value={draft.themeColor}
                    onChange={(e) => onChange({ themeColor: e.target.value.toUpperCase() })}
                    className="w-11 h-11 rounded-xl border border-slate-300 cursor-pointer p-1 bg-white"
                  />
                  <input
                    type="text"
                    value={draft.themeColor}
                    maxLength={7}
                    onChange={(e) => onChange({ themeColor: e.target.value.toUpperCase() })}
                    className="flex-1 min-h-[44px] px-3 rounded-xl border border-slate-300 text-sm font-mono text-slate-900"
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="splash-color-input"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Fundo da Tela de Abertura (Splash)
                </label>
                <div className="flex items-center gap-2.5">
                  <input
                    id="splash-color-input"
                    type="color"
                    value={draft.splashBgColor}
                    onChange={(e) => onChange({ splashBgColor: e.target.value.toUpperCase() })}
                    className="w-11 h-11 rounded-xl border border-slate-300 cursor-pointer p-1 bg-white"
                  />
                  <input
                    type="text"
                    value={draft.splashBgColor}
                    maxLength={7}
                    onChange={(e) => onChange({ splashBgColor: e.target.value.toUpperCase() })}
                    className="flex-1 min-h-[44px] px-3 rounded-xl border border-slate-300 text-sm font-mono text-slate-900"
                  />
                </div>
              </div>
            </div>

            <div>
              <span className="block text-xs font-semibold text-slate-700 mb-2">
                Animação do Ícone ao Abrir o App
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                {(
                  [
                    { id: 'zoom', label: 'Zoom Suave' },
                    { id: 'pulse', label: 'Pulso' },
                    { id: 'bounce', label: 'Quique' },
                    { id: 'fade', label: 'Fade' },
                    { id: 'none', label: 'Sem Animação' },
                  ] as Array<{ id: SplashAnimation; label: string }>
                ).map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => onChange({ splashAnimation: item.id })}
                    className={`min-h-[44px] px-2.5 py-2 rounded-xl text-xs font-semibold border transition-colors cursor-pointer ${
                      draft.splashAnimation === item.id
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <hr className="border-slate-200" />

          {/* Mobile Viewport & External Apps */}
          <div className="space-y-3">
            <h3 className="font-display text-sm font-bold text-slate-900">
              Experiência Igual APK Mobile (Sem Desktop / Sem Zoom / Links Externos)
            </h3>

            <label className="flex items-start justify-between gap-3 p-3.5 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer">
              <div>
                <p className="text-xs sm:text-sm font-semibold text-slate-900">
                  Travar modo mobile (nunca abrir versão desktop)
                </p>
                <p className="text-xs text-slate-500 mt-0.5">
                  Usa agente móvel Android e injeta viewport responsivo para o site ficar exatamente
                  como aplicativo nativo.
                </p>
              </div>
              <input
                type="checkbox"
                checked={draft.lockMobileViewport}
                onChange={(e) => onChange({ lockMobileViewport: e.target.checked })}
                className="w-5 h-5 mt-0.5 accent-blue-600 shrink-0 cursor-pointer"
              />
            </label>

            <label className="flex items-start justify-between gap-3 p-3.5 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer">
              <div>
                <p className="text-xs sm:text-sm font-semibold text-slate-900">
                  Desativar zoom com os dedos (igual app nativo)
                </p>
                <p className="text-xs text-slate-500 mt-0.5">
                  Impede zoom acidental de página para manter os botões e menus fixos como em um APK
                  nativo.
                </p>
              </div>
              <input
                type="checkbox"
                checked={draft.disableZoom}
                onChange={(e) => onChange({ disableZoom: e.target.checked })}
                className="w-5 h-5 mt-0.5 accent-blue-600 shrink-0 cursor-pointer"
              />
            </label>

            <label className="flex items-start justify-between gap-3 p-3.5 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer">
              <div>
                <p className="text-xs sm:text-sm font-semibold text-slate-900">
                  Abrir outros aplicativos (YouTube, WhatsApp, Maps, Pix)
                </p>
                <p className="text-xs text-slate-500 mt-0.5">
                  Permite que o site abra o app do YouTube, WhatsApp, telefone ou links{' '}
                  <span className="font-mono">intent://</span> instalados no celular quando
                  solicitado.
                </p>
              </div>
              <input
                type="checkbox"
                checked={draft.openExternalApps}
                onChange={(e) => onChange({ openExternalApps: e.target.checked })}
                className="w-5 h-5 mt-0.5 accent-blue-600 shrink-0 cursor-pointer"
              />
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <label className="flex items-center justify-between gap-3 p-3 rounded-xl border border-slate-200 cursor-pointer">
                <span className="text-xs sm:text-sm font-medium text-slate-800">
                  Barra superior do app
                </span>
                <input
                  type="checkbox"
                  checked={draft.showNavBar}
                  onChange={(e) => onChange({ showNavBar: e.target.checked })}
                  className="w-5 h-5 accent-blue-600 cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between gap-3 p-3 rounded-xl border border-slate-200 cursor-pointer">
                <span className="text-xs sm:text-sm font-medium text-slate-800">
                  Botão atualizar página
                </span>
                <input
                  type="checkbox"
                  checked={draft.pullToRefresh}
                  onChange={(e) => onChange({ pullToRefresh: e.target.checked })}
                  className="w-5 h-5 accent-blue-600 cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between gap-3 p-3 rounded-xl border border-slate-200 cursor-pointer">
                <span className="text-xs sm:text-sm font-medium text-slate-800">
                  Modo tela cheia (Imersivo)
                </span>
                <input
                  type="checkbox"
                  checked={draft.fullscreenMode}
                  onChange={(e) => onChange({ fullscreenMode: e.target.checked })}
                  className="w-5 h-5 accent-blue-600 cursor-pointer"
                />
              </label>

              <div className="flex items-center justify-between gap-3 p-3 rounded-xl border border-slate-200">
                <label
                  htmlFor="orientation-select"
                  className="text-xs sm:text-sm font-medium text-slate-800"
                >
                  Orientação
                </label>
                <select
                  id="orientation-select"
                  value={draft.orientation}
                  onChange={(e) => onChange({ orientation: e.target.value as AppOrientation })}
                  className="text-xs font-semibold text-slate-800 bg-slate-100 rounded-lg px-2.5 py-1.5 border border-slate-200"
                >
                  <option value="portrait">Retrato</option>
                  <option value="landscape">Paisagem</option>
                  <option value="sensor">Automática</option>
                </select>
              </div>
            </div>
          </div>

          <hr className="border-slate-200" />

          {/* Native Permissions */}
          <div className="space-y-3">
            <div>
              <h3 className="font-display text-sm font-bold text-slate-900">
                Autorizações Nativas do Aplicativo
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Escolha quais recursos do celular o site poderá solicitar dentro do APK gerado.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <label className="flex items-center justify-between gap-3 p-3 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer">
                <span className="inline-flex items-center gap-2 text-xs sm:text-sm font-medium text-slate-800">
                  <Camera className="w-4 h-4 text-slate-500" />
                  Câmera
                </span>
                <input
                  type="checkbox"
                  checked={draft.permCamera}
                  onChange={(e) => onChange({ permCamera: e.target.checked })}
                  className="w-5 h-5 accent-blue-600 cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between gap-3 p-3 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer">
                <span className="inline-flex items-center gap-2 text-xs sm:text-sm font-medium text-slate-800">
                  <Mic className="w-4 h-4 text-slate-500" />
                  Microfone
                </span>
                <input
                  type="checkbox"
                  checked={draft.permMicrophone}
                  onChange={(e) => onChange({ permMicrophone: e.target.checked })}
                  className="w-5 h-5 accent-blue-600 cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between gap-3 p-3 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer">
                <span className="inline-flex items-center gap-2 text-xs sm:text-sm font-medium text-slate-800">
                  <MapPin className="w-4 h-4 text-slate-500" />
                  Localização (GPS)
                </span>
                <input
                  type="checkbox"
                  checked={draft.permLocation}
                  onChange={(e) => onChange({ permLocation: e.target.checked })}
                  className="w-5 h-5 accent-blue-600 cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between gap-3 p-3 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer">
                <span className="inline-flex items-center gap-2 text-xs sm:text-sm font-medium text-slate-800">
                  <FolderOpen className="w-4 h-4 text-slate-500" />
                  Arquivos e Galeria
                </span>
                <input
                  type="checkbox"
                  checked={draft.permFiles}
                  onChange={(e) => onChange({ permFiles: e.target.checked })}
                  className="w-5 h-5 accent-blue-600 cursor-pointer"
                />
              </label>

              <label className="sm:col-span-2 flex items-center justify-between gap-3 p-3 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer">
                <span className="inline-flex items-center gap-2 text-xs sm:text-sm font-medium text-slate-800">
                  <Fingerprint className="w-4 h-4 text-slate-500" />
                  Biometria / Desbloqueio do Aparelho ao Abrir
                </span>
                <input
                  type="checkbox"
                  checked={draft.permBiometrics}
                  onChange={(e) => onChange({ permBiometrics: e.target.checked })}
                  className="w-5 h-5 accent-blue-600 cursor-pointer"
                />
              </label>
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="button"
              onClick={onSaveNow}
              disabled={isSaving}
              className="min-h-[44px] px-5 py-2.5 rounded-xl bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700 disabled:opacity-60 transition-colors inline-flex items-center gap-2 cursor-pointer"
            >
              {isSaving ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Save className="w-4 h-4" />
              )}
              <span>Salvar Aparência e Permissões</span>
            </button>
          </div>
        </div>
      )}

      {/* TAB 3: EXPORTAR APK & AAB */}
      {activeTab === 'exportar' && (
        <div className="space-y-4">
          <div className="bg-white border border-slate-200 rounded-2xl p-5">
            <div className="flex items-start justify-between gap-4 mb-4">
              <div>
                <h3 className="font-display text-base font-bold text-slate-900">
                  Exportar Pacote Final Grátis
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 mt-1">
                  O arquivo <span className="font-semibold">.apk</span> é compilado em código
                  nativo Android, alinhado (<span className="font-mono">zipalign</span>) e assinado
                  com esquema criptográfico v1 + v2 pronto para instalar no celular.
                </p>
              </div>
              <span className="text-xs font-mono tabular-nums text-slate-500 whitespace-nowrap shrink-0">
                v{draft.versionName} ({draft.versionCode})
              </span>
            </div>

            <div className="grid grid-cols-1 gap-3.5">
              {/* APK Card */}
              <div className="border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-start gap-3.5">
                  <div className="w-11 h-11 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                    <Package className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-display text-sm font-bold text-slate-900">
                      Arquivo APK Instalável (.apk)
                    </h4>
                    <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                      Contém <span className="font-mono">classes.dex</span> nativo compilado,{' '}
                      <span className="font-mono">AndroidManifest.xml</span> binário, assinatura
                      APK v1 + v2, bloqueio de zoom, permissões selecionadas e splash animada.
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => onExport('apk')}
                  disabled={exportingFormat !== null}
                  className="min-h-[44px] px-5 py-2.5 rounded-xl bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700 disabled:opacity-60 transition-colors inline-flex items-center justify-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  {exportingFormat === 'apk' ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Download className="w-4 h-4" />
                  )}
                  <span>{exportingFormat === 'apk' ? 'Gerando APK...' : 'Baixar APK'}</span>
                </button>
              </div>

              {/* AAB Card */}
              <div className="border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-start gap-3.5">
                  <div className="w-11 h-11 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
                    <FileArchive className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-display text-sm font-bold text-slate-900">
                      Android App Bundle (.aab)
                    </h4>
                    <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                      Estrutura modular AAB (<span className="font-mono">base/manifest</span>,{' '}
                      <span className="font-mono">BundleConfig.pb</span>,{' '}
                      <span className="font-mono">classes.dex</span> compilado e ícone).
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => onExport('aab')}
                  disabled={exportingFormat !== null}
                  className="min-h-[44px] px-5 py-2.5 rounded-xl bg-slate-900 text-white text-sm font-semibold hover:bg-slate-800 disabled:opacity-60 transition-colors inline-flex items-center justify-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  {exportingFormat === 'aab' ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Download className="w-4 h-4" />
                  )}
                  <span>{exportingFormat === 'aab' ? 'Gerando AAB...' : 'Baixar AAB'}</span>
                </button>
              </div>

              {/* Android Studio Source ZIP Card */}
              <div className="border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-50/70">
                <div className="flex items-start gap-3.5">
                  <div className="w-11 h-11 rounded-xl bg-slate-200 text-slate-700 flex items-center justify-center shrink-0">
                    <Code2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-display text-sm font-bold text-slate-900">
                      Projeto Android Studio Completo (.zip)
                    </h4>
                    <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                      Código-fonte Java + Gradle completo para compilar e assinar com sua chave de
                      desenvolvedor da Play Console.
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => onExport('source')}
                  disabled={exportingFormat !== null}
                  className="min-h-[44px] px-4 py-2.5 rounded-xl border border-slate-300 bg-white text-slate-800 text-xs sm:text-sm font-semibold hover:bg-slate-100 disabled:opacity-60 transition-colors inline-flex items-center justify-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  {exportingFormat === 'source' ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Download className="w-4 h-4" />
                  )}
                  <span>
                    {exportingFormat === 'source' ? 'Empacotando...' : 'Baixar Projeto ZIP'}
                  </span>
                </button>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
              <span>
                Manifesto Web PWA:{' '}
                <a
                  href={`/api/manifest/${draft.id}.json`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-mono text-blue-600 hover:underline inline-flex items-center gap-1"
                >
                  /api/manifest/{draft.id}.json
                  <ExternalLink className="w-3 h-3" />
                </a>
              </span>
              <span>
                {draft.lastExportFormat
                  ? `Última exportação: ${draft.lastExportFormat.toUpperCase()}`
                  : 'Nenhuma exportação registrada ainda'}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: HISTÓRICO */}
      {activeTab === 'historico' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-5">
          <div className="flex items-center justify-between gap-3 mb-4">
            <div>
              <h3 className="font-display text-base font-bold text-slate-900">
                Histórico de Atualizações e Exportações
              </h3>
              <p className="text-xs text-slate-500">
                Registro em tempo real das alterações de nome, link, ícone e pacotes gerados.
              </p>
            </div>
            <span className="text-xs font-mono tabular-nums text-slate-500">
              {revisions.length} {revisions.length === 1 ? 'registro' : 'registros'}
            </span>
          </div>

          {revisions.length === 0 ? (
            <div className="py-10 text-center border border-dashed border-slate-200 rounded-xl">
              <History className="w-8 h-8 text-slate-300 mx-auto mb-2" />
              <p className="text-sm font-medium text-slate-700">Sem registros ainda</p>
              <p className="text-xs text-slate-500 mt-1">
                Salve uma atualização ou exporte em APK/AAB para registrar aqui.
              </p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {revisions.map((rev) => {
                const dateText = rev.createdAt
                  ? rev.createdAt.toDate().toLocaleString('pt-BR', {
                      day: '2-digit',
                      month: '2-digit',
                      hour: '2-digit',
                      minute: '2-digit',
                    })
                  : 'Agora';

                return (
                  <div key={rev.id} className="py-3.5 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-9 h-9 rounded-lg border border-slate-200 bg-slate-50 flex items-center justify-center overflow-hidden shrink-0">
                        {rev.iconSnapshot ? (
                          <img
                            src={rev.iconSnapshot}
                            alt={rev.nameSnapshot}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-contain p-1"
                          />
                        ) : (
                          <Smartphone className="w-4 h-4 text-slate-400" />
                        )}
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-slate-900 truncate">
                          {rev.changeSummary}
                        </p>
                        <p className="text-xs text-slate-500 truncate">
                          {rev.nameSnapshot} · <span className="font-mono">{rev.urlSnapshot}</span>
                        </p>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <p className="text-xs font-mono font-semibold text-slate-800 uppercase">
                        {rev.exportFormat} · v{rev.versionName}
                      </p>
                      <p className="text-[11px] text-slate-500 tabular-nums">{dateText}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
